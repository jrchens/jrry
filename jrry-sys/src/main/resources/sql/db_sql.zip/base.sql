/*
MySQL Backup
Database: base
Backup Time: 2018-03-10 22:12:31
*/

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS `base`.`_table_template`;
DROP TABLE IF EXISTS `base`.`attachment`;
DROP TABLE IF EXISTS `base`.`base_message`;
DROP TABLE IF EXISTS `base`.`cms_article`;
DROP TABLE IF EXISTS `base`.`cms_category`;
DROP TABLE IF EXISTS `base`.`data_directory`;
DROP TABLE IF EXISTS `base`.`data_item`;
DROP TABLE IF EXISTS `base`.`data_table`;
DROP TABLE IF EXISTS `base`.`data_table_item_relation`;
DROP TABLE IF EXISTS `base`.`sample`;
DROP TABLE IF EXISTS `base`.`sample_bar`;
DROP TABLE IF EXISTS `base`.`sample_detail`;
DROP TABLE IF EXISTS `base`.`sample_foo`;
DROP TABLE IF EXISTS `base`.`sample_foo_bar_relation`;
DROP TABLE IF EXISTS `base`.`sys_config`;
DROP TABLE IF EXISTS `base`.`sys_group`;
DROP TABLE IF EXISTS `base`.`sys_permission`;
DROP TABLE IF EXISTS `base`.`sys_role`;
DROP TABLE IF EXISTS `base`.`sys_role_permission_relation`;
DROP TABLE IF EXISTS `base`.`sys_user`;
DROP TABLE IF EXISTS `base`.`sys_user_group_relation`;
DROP TABLE IF EXISTS `base`.`sys_user_role_relation`;
DROP TABLE IF EXISTS `base`.`wx_access_token`;
DROP TABLE IF EXISTS `base`.`wx_area_info`;
DROP TABLE IF EXISTS `base`.`wx_jsapi_ticket`;
DROP TABLE IF EXISTS `base`.`wx_menu`;
DROP TABLE IF EXISTS `base`.`wx_menu_match_rule`;
DROP TABLE IF EXISTS `base`.`wx_tag`;
DROP TABLE IF EXISTS `base`.`wx_user_info`;
DROP TABLE IF EXISTS `base`.`wx_user_info_tag_relation`;
DROP TABLE IF EXISTS `base`.`wx_web_access_token`;
CREATE TABLE `_table_template` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `srt` int(10) unsigned NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `cruser` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '创建用户',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '更新用户',
  `mdtime` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `attachment` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `original_file_name` varchar(200) CHARACTER SET utf8 NOT NULL COMMENT '原始文件名',
  `save_path` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '保存路径',
  `file_name` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '文件名',
  `file_size` bigint(20) unsigned NOT NULL COMMENT '文件大小',
  `file_type` varchar(200) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '文件类型',
  `file_sha1` varchar(40) CHARACTER SET utf8 NOT NULL COMMENT '文件hash',
  `owner` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '所有者',
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `cruser` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '创建用户',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '更新用户',
  `mdtime` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `base_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `message` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=1006 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `cms_article` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `category` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '类别名称',
  `cover_image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '封面图片',
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '标题',
  `intro` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '简介',
  `rich_content` text COLLATE utf8_unicode_ci NOT NULL COMMENT '内容',
  `pub_date` date NOT NULL COMMENT '发布日期',
  `pub_user` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '发布人',
  `is_viewable` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否可见',
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `cruser` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '创建用户',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '更新用户',
  `mdtime` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `cms_category` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `parent_id` bigint(20) unsigned NOT NULL COMMENT '父ID',
  `category` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '类别代码',
  `category_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '类别名称',
  `sort` int(4) unsigned NOT NULL DEFAULT '1' COMMENT '排序',
  `is_link` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否链接',
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `cruser` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '创建用户',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '更新用户',
  `mdtime` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `data_directory` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `directory_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `view_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `srt` int(10) NOT NULL,
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `cruser` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '创建用户',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '更新用户',
  `mdtime` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `data_item` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `ref_id` bigint(20) NOT NULL,
  `item_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `view_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `data_type` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `is_nullable` tinyint(1) NOT NULL,
  `item_length` int(11) DEFAULT NULL,
  `item_scale` int(11) DEFAULT NULL,
  `item_pattern` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_comment` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `cruser` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '创建用户',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '更新用户',
  `mdtime` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `data_table` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `directory_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `table_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `view_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `srt` int(10) NOT NULL,
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `cruser` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '创建用户',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '更新用户',
  `mdtime` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `data_table_item_relation` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `table_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `item_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `srt` int(10) DEFAULT NULL,
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `cruser` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '创建用户',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '更新用户',
  `mdtime` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `sample` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `bcode` char(36) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '代码',
  `btitle` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '标题',
  `bint` int(11) unsigned DEFAULT NULL COMMENT '无符号整数',
  `bnum` decimal(15,2) unsigned DEFAULT NULL COMMENT '无符号小数',
  `bdate` date DEFAULT NULL COMMENT '日期（YYYY-MM-DD）',
  `bdatetime` datetime DEFAULT NULL COMMENT '日期时间',
  `is_btinyint` tinyint(1) unsigned DEFAULT NULL COMMENT '布尔值',
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '已删除（1:Y,0:N）',
  `cruser` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '创建者',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '修改者',
  `mdtime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_bcode` (`bcode`),
  KEY `idx_btitle` (`btitle`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='样例表';
CREATE TABLE `sample_bar` (
  `id` bigint(20) NOT NULL,
  `bcode` char(36) COLLATE utf8_unicode_ci NOT NULL COMMENT '代码',
  `title` varchar(200) COLLATE utf8_unicode_ci NOT NULL COMMENT '标题',
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '已删除（1:Y,0:N）',
  `cruser` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '创建者',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '修改者',
  `mdtime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_bcode` (`bcode`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='表Bar';
CREATE TABLE `sample_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sample_id` bigint(20) NOT NULL,
  `bcontent` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '已删除（1:Y,0:N）',
  `cruser` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '创建者',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '修改者',
  `mdtime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_sample_id` (`sample_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `sample_foo` (
  `id` bigint(20) NOT NULL,
  `fcode` char(36) COLLATE utf8_unicode_ci NOT NULL COMMENT '代码',
  `title` varchar(200) COLLATE utf8_unicode_ci NOT NULL COMMENT '标题',
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '已删除（1:Y,0:N）',
  `cruser` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '创建者',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '修改者',
  `mdtime` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_fcode` (`fcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='表Foo';
CREATE TABLE `sample_foo_bar_relation` (
  `id` bigint(20) NOT NULL,
  `foo_id` bigint(20) NOT NULL,
  `bar_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `sys_config` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cfg_code` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `cfg_type` tinyint(4) unsigned NOT NULL DEFAULT '1',
  `cfg_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `cfg_value` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `cfg_group` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cruser` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `crtime` datetime NOT NULL,
  `mduser` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cfg_code` (`cfg_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `sys_group` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `group_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `viewname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cruser` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `crtime` datetime NOT NULL,
  `mduser` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_name` (`group_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `sys_permission` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `permission` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `viewname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cruser` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `crtime` datetime NOT NULL,
  `mduser` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permission` (`permission`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `sys_role` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `viewname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cruser` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `crtime` datetime NOT NULL,
  `mduser` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_name` (`role_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `sys_role_permission_relation` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `permission` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `sys_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `viewname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `password_salt` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `is_disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_locked` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cruser` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `crtime` datetime NOT NULL,
  `mduser` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`) USING HASH,
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `sys_user_group_relation` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `group_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `is_def` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `sys_user_role_relation` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `role_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `is_def` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `wx_access_token` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `access_token` varchar(200) DEFAULT NULL,
  `expires_in` int(4) DEFAULT NULL,
  `expires_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `wx_area_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `country` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '国家',
  `province` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '省份',
  `city` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '城市',
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `cruser` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '创建用户',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '更新用户',
  `mdtime` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `wx_jsapi_ticket` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ticket` varchar(200) DEFAULT NULL,
  `expires_in` int(4) DEFAULT NULL,
  `expires_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `wx_menu` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `node_type` varchar(50) DEFAULT NULL,
  `node_name` varchar(50) DEFAULT NULL,
  `node_key` varchar(50) DEFAULT NULL,
  `node_url` varchar(200) DEFAULT NULL,
  `node_media_id` varchar(50) DEFAULT NULL,
  `node_appid` varchar(50) DEFAULT NULL,
  `node_pagepath` varchar(200) DEFAULT NULL,
  `view_scope` varchar(50) DEFAULT NULL,
  `is_custom` tinyint(1) unsigned DEFAULT '0' COMMENT '是否个性化菜单',
  `menuid` bigint(20) DEFAULT NULL COMMENT '微信个性化菜单编号',
  `rich_content` varchar(200) DEFAULT NULL,
  `sort` int(11) unsigned DEFAULT '1',
  `url_state` varchar(50) DEFAULT NULL,
  `is_deleted` tinyint(1) unsigned DEFAULT '0',
  `cruser` varchar(50) DEFAULT NULL,
  `crtime` datetime DEFAULT NULL,
  `mduser` varchar(50) DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
CREATE TABLE `wx_menu_match_rule` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `menu_id` bigint(20) unsigned NOT NULL COMMENT '菜单外键',
  `tag_id` bigint(20) DEFAULT NULL COMMENT '用户标签',
  `sex` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '性别',
  `country` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '国家信息',
  `province` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '省份信息',
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '城市信息',
  `client_platform_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '客户端版本',
  `language` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '语言信息',
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `cruser` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '创建用户',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '更新用户',
  `mdtime` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `wx_tag` (
  `id` bigint(20) unsigned NOT NULL COMMENT '主键',
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '标签名',
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `cruser` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '创建用户',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '更新用户',
  `mdtime` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `wx_user_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `openid` varchar(50) NOT NULL DEFAULT '',
  `viewname` varchar(50) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `nickname` varchar(50) DEFAULT NULL,
  `sex` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `headimgurl` varchar(500) DEFAULT NULL,
  `privilege` text,
  `unionid` varchar(50) DEFAULT NULL,
  `is_enable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cruser` varchar(50) NOT NULL,
  `crtime` datetime NOT NULL,
  `mduser` varchar(50) DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `openid` (`openid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `wx_user_info_tag_relation` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `openid` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `tag_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `wx_web_access_token` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `access_token` varchar(200) DEFAULT NULL,
  `expires_in` int(4) DEFAULT NULL,
  `expires_time` datetime DEFAULT NULL,
  `openid` varchar(100) DEFAULT NULL,
  `refresh_token` varchar(200) DEFAULT NULL,
  `scope` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
BEGIN;
LOCK TABLES `base`.`_table_template` WRITE;
DELETE FROM `base`.`_table_template`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`attachment` WRITE;
DELETE FROM `base`.`attachment`;
INSERT INTO `base`.`attachment` (`id`,`original_file_name`,`save_path`,`file_name`,`file_size`,`file_type`,`file_sha1`,`owner`,`is_deleted`,`cruser`,`crtime`,`mduser`,`mdtime`) VALUES (2, 'blue.png', '/2018/01/19', '15163505122975626.png', 7735, 'image/png', '8acbbbe4fc77a51c29fbece5f93eaafc41a328f0', 'admin', 0, 'admin', '2018-01-19 16:28:32', NULL, NULL),(3, 'yellow.png', '/2018/01/19', '15163506188528604.png', 7728, 'image/png', 'ecca0fc6e41b345d8d406f871113acdc671c2fcf', 'admin', 0, 'admin', '2018-01-19 16:30:19', NULL, NULL),(4, 'blue.png', '/2018/01/19', '15163505122975626.png', 7735, 'image/png', '8acbbbe4fc77a51c29fbece5f93eaafc41a328f0', 'admin', 0, 'admin', '2018-01-19 16:28:32', NULL, NULL),(5, 'yellow.png', '/2018/01/19', '15163506188528604.png', 7728, 'image/png', 'ecca0fc6e41b345d8d406f871113acdc671c2fcf', 'admin', 0, 'admin', '2018-01-19 16:30:19', NULL, NULL),(6, 'red.png', '/2018/01/19', '1516360318266195902.png', 8163, 'image/png', '55e6f77b0edcadfef502c4df4a54a7716024dea4', 'admin', 0, 'admin', '2018-01-19 19:11:58', NULL, NULL),(7, 'green.png', '/2018/01/19', '1516360318270538772.png', 8224, 'image/png', '4c1cd4be9ee9dce4ba25acf66aa38ce1315fbd4b', 'admin', 0, 'admin', '2018-01-19 19:11:58', NULL, NULL),(8, '阿里JAVA开发规范.pdf', '/2018/01/19', '1516361781495349000.pdf', 792570, 'application/pdf', 'f400657493bc8b29faa3559f62eaad5cdbc38f05', 'admin', 0, 'admin', '2018-01-19 19:36:21', NULL, NULL),(9, 'spring-framework-reference.pdf', '/2018/01/19', '1516368569929623619.pdf', 5604140, 'application/pdf', '307098b1170c54ba1301386ca8206f4b9306bbff', 'admin', 0, 'admin', '2018-01-19 21:29:30', NULL, NULL),(10, 'spring-framework-reference.pdf', '/2018/01/19', '1516368569929623619.pdf', 5604140, 'application/pdf', '307098b1170c54ba1301386ca8206f4b9306bbff', 'admin', 0, 'admin', '2018-01-19 21:29:30', NULL, NULL),(11, 'bootstrap-3.3.7.zip', '/2018/01/19', '1516372352414634645.zip', 4297547, 'application/zip', '27f8328a7ffa1f09d800e08cf190fc76e0596ae6', 'admin', 0, 'admin', '2018-01-19 22:32:32', NULL, NULL),(12, '车牌识别一体机Tcp通讯协议说明文档.pdf', '/2018/01/19', '1516372406231277808.pdf', 950677, 'application/pdf', 'c63216b1ea3c8987804264ce1a3e0b3b64cb8c2d', 'mason', 0, 'mason', '2018-01-19 22:33:26', NULL, NULL);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`base_message` WRITE;
DELETE FROM `base`.`base_message`;
INSERT INTO `base`.`base_message` (`id`,`code`,`message`) VALUES (400, 'bad_request', 'bad.request'),(1001, 'login:user_not_found', 'login.failed,user.not.found'),(1002, 'login:password_error', 'login.failed,password.error'),(1003, 'login:user_locked', 'login.failed,user.locked'),(1004, 'login:user_disabled', 'login.failed,user.disabled'),(1005, 'login:failed', 'login.failed');
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`cms_article` WRITE;
DELETE FROM `base`.`cms_article`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`cms_category` WRITE;
DELETE FROM `base`.`cms_category`;
INSERT INTO `base`.`cms_category` (`id`,`parent_id`,`category`,`category_name`,`sort`,`is_link`,`is_deleted`,`cruser`,`crtime`,`mduser`,`mdtime`) VALUES (1, 0, 'root', '类别管理', 1, 0, 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(2, 1, '/index.html', '首页', 1, 1, 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(3, 1, '002', '信用组织', 2, 0, 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(4, 1, '003', '信用动态', 3, 0, 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(5, 1, '004', '信用资讯', 4, 0, 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(6, 1, '005', '诚信红黑榜', 5, 0, 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(7, 1, '006', '信用查询', 6, 0, 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(8, 1, '007', '信用知识', 7, 0, 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(9, 1, '008', '政策法规', 8, 0, 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(10, 1, '009', '通知公告', 9, 0, 0, 'admin', '2010-10-10 10:10:10', NULL, NULL);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`data_directory` WRITE;
DELETE FROM `base`.`data_directory`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`data_item` WRITE;
DELETE FROM `base`.`data_item`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`data_table` WRITE;
DELETE FROM `base`.`data_table`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`data_table_item_relation` WRITE;
DELETE FROM `base`.`data_table_item_relation`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`sample` WRITE;
DELETE FROM `base`.`sample`;
INSERT INTO `base`.`sample` (`id`,`bcode`,`btitle`,`bint`,`bnum`,`bdate`,`bdatetime`,`is_btinyint`,`is_deleted`,`cruser`,`crtime`,`mduser`,`mdtime`) VALUES (1, 'E3725437-DB2B-4F42-886D-6C45D7560001', 'E3725437-DB2B-4F42-886D-6C45D7561111', 256, 655.35, '2018-01-06', '2018-01-04 14:29:55', 0, 0, 'admin', '2018-01-04 14:29:55', 'admin', '2018-01-04 22:03:58'),(2, 'E3725437-DB2B-4F42-886D-6C45D7561002', 'E3725437-DB2B-4F42-886D-6C45D7561002', 32, 10.24, '2018-01-05', '2018-01-04 14:29:56', 0, 0, 'admin', '2018-01-04 14:29:56', 'admin', '2018-01-04 21:57:22'),(3, 'E3725437-DB2B-4F42-886D-6C45D7562003', 'E3725437-DB2B-4F42-886D-6C45D7562003', 30, 45.12, '2018-01-06', '2018-01-04 14:29:57', 0, 0, 'admin', '2018-01-04 14:29:57', 'admin', '2018-01-04 22:05:09'),(4, 'E3725437-DB2B-4F42-886D-6C45D7563004', 'E3725437-DB2B-4F42-886D-6C45D7563004', 40, 46.12, '2018-01-07', '2018-01-04 14:29:58', 0, 0, 'admin', '2018-01-04 14:29:58', 'admin', '2018-01-04 22:40:29'),(5, 'E3725437-DB2B-4F42-886D-6C45D7564005', 'E3725437-DB2B-4F42-886D-6C45D7564005', 50, 47.12, '2018-01-08', '2018-01-04 14:29:59', 0, 0, 'admin', '2018-01-04 14:29:59', NULL, NULL),(6, 'E3725437-DB2B-4F42-886D-6C45D7565006', 'E3725437-DB2B-4F42-886D-6C45D7565006', 60, 48.12, '2018-01-09', '2018-01-04 14:30:00', 0, 0, 'admin', '2018-01-04 14:30:00', NULL, NULL),(7, 'E3725437-DB2B-4F42-886D-6C45D7566007', 'E3725437-DB2B-4F42-886D-6C45D7566007', 70, 49.12, '2018-01-10', '2018-01-04 14:30:01', 0, 0, 'admin', '2018-01-04 14:30:01', NULL, NULL),(8, 'E3725437-DB2B-4F42-886D-6C45D7567008', 'E3725437-DB2B-4F42-886D-6C45D7567008', 80, 50.12, '2018-01-11', '2018-01-04 14:30:02', 0, 0, 'admin', '2018-01-04 14:30:02', NULL, NULL),(9, 'E3725437-DB2B-4F42-886D-6C45D7568009', 'E3725437-DB2B-4F42-886D-6C45D7568009', 90, 51.12, '2018-01-12', '2018-01-04 14:30:03', 0, 0, 'admin', '2018-01-04 14:30:03', NULL, NULL),(10, 'E3725437-DB2B-4F42-886D-6C45D7569010', 'E3725437-DB2B-4F42-886D-6C45D7569010', 100, 52.12, '2018-01-13', '2018-01-04 14:30:04', 0, 0, 'admin', '2018-01-04 14:30:04', NULL, NULL),(11, 'E3725437-DB2B-4F42-886D-6C45D7570011', 'E3725437-DB2B-4F42-886D-6C45D7570011', 110, 53.12, '2018-01-14', '2018-01-04 14:30:05', 0, 0, 'admin', '2018-01-04 14:30:05', NULL, NULL),(12, 'E3725437-DB2B-4F42-886D-6C45D7571012', 'E3725437-DB2B-4F42-886D-6C45D7571012', 120, 54.12, '2018-01-15', '2018-01-04 14:30:06', 0, 0, 'admin', '2018-01-04 14:30:06', NULL, NULL),(13, 'E3725437-DB2B-4F42-886D-6C45D7572013', 'E3725437-DB2B-4F42-886D-6C45D7572013', 130, 55.12, '2018-01-16', '2018-01-04 14:30:07', 0, 0, 'admin', '2018-01-04 14:30:07', NULL, NULL),(14, 'E3725437-DB2B-4F42-886D-6C45D7573014', 'E3725437-DB2B-4F42-886D-6C45D7573014', 140, 56.12, '2018-01-17', '2018-01-04 14:30:08', 0, 0, 'admin', '2018-01-04 14:30:08', NULL, NULL),(15, 'E3725437-DB2B-4F42-886D-6C45D7574015', 'E3725437-DB2B-4F42-886D-6C45D7574015', 150, 57.12, '2018-01-18', '2018-01-04 14:30:09', 0, 0, 'admin', '2018-01-04 14:30:09', NULL, NULL),(16, 'E3725437-DB2B-4F42-886D-6C45D7575016', 'E3725437-DB2B-4F42-886D-6C45D7575016', 160, 58.12, '2018-01-19', '2018-01-04 14:30:10', 0, 0, 'admin', '2018-01-04 14:30:10', NULL, NULL),(17, 'E3725437-DB2B-4F42-886D-6C45D7576017', 'E3725437-DB2B-4F42-886D-6C45D7576017', 170, 59.12, '2018-01-20', '2018-01-04 14:30:11', 0, 0, 'admin', '2018-01-04 14:30:11', NULL, NULL),(18, 'E3725437-DB2B-4F42-886D-6C45D7577018', 'E3725437-DB2B-4F42-886D-6C45D7577018', 180, 60.12, '2018-01-21', '2018-01-04 14:30:12', 0, 0, 'admin', '2018-01-04 14:30:12', NULL, NULL),(19, 'E3725437-DB2B-4F42-886D-6C45D7578019', 'E3725437-DB2B-4F42-886D-6C45D7578019', 190, 61.12, '2018-01-22', '2018-01-04 14:30:13', 0, 0, 'admin', '2018-01-04 14:30:13', NULL, NULL),(20, 'E3725437-DB2B-4F42-886D-6C45D7579020', 'E3725437-DB2B-4F42-886D-6C45D7579020', 200, 62.12, '2018-01-23', '2018-01-04 14:30:14', 0, 0, 'admin', '2018-01-04 14:30:14', NULL, NULL),(21, 'E3725437-DB2B-4F42-886D-6C45D7580021', 'E3725437-DB2B-4F42-886D-6C45D7580021', 210, 63.12, '2018-01-24', '2018-01-04 14:30:15', 0, 0, 'admin', '2018-01-04 14:30:15', NULL, NULL),(22, 'E3725437-DB2B-4F42-886D-6C45D7581022', 'E3725437-DB2B-4F42-886D-6C45D7581022', 220, 64.12, '2018-01-25', '2018-01-04 14:30:16', 0, 0, 'admin', '2018-01-04 14:30:16', NULL, NULL),(23, 'E3725437-DB2B-4F42-886D-6C45D7582023', 'E3725437-DB2B-4F42-886D-6C45D7582023', 230, 65.12, '2018-01-26', '2018-01-04 14:30:17', 0, 0, 'admin', '2018-01-04 14:30:17', 'admin', '2018-01-05 22:06:21'),(24, 'E3725437-DB2B-4F42-886D-6C45D7583024', 'E3725437-DB2B-4F42-886D-6C45D7583024', 240, 66.12, '2018-01-27', '2018-01-04 14:30:18', 0, 1, 'admin', '2018-01-04 14:30:18', 'admin', '2018-01-09 21:54:42'),(25, 'E3725437-DB2B-4F42-886D-6C45D7584025', 'E3725437-DB2B-4F42-886D-6C45D7584025', 250, 67.12, '2018-01-28', '2018-01-04 14:30:19', 1, 1, 'admin', '2018-01-04 14:30:19', 'admin', '2018-01-09 21:54:36'),(26, '4CD8D1F2-EEDB-4278-A3A2-BACE1D47E22F', '4CD8D1F2-EEDB-4278-A3A2-BACE1D47E22F', 32, 20.48, '2018-01-04', '2018-01-04 22:17:27', 0, 1, 'admin', '2018-01-04 22:17:27', 'admin', '2018-01-09 21:54:06'),(29, '4CD8D1F2-EEDB-4278-A3A2-BACE1D47E29F', '4CD8D1F2-EEDB-4278-A3A2-BACE1D47E22F', 1024, 4096.16, '2018-01-01', '2018-01-10 22:35:12', 1, 1, 'admin', '2018-01-04 22:35:12', 'admin', '2018-01-09 21:53:58'),(48, 'E3725437-DB2B-4F42-886D-6C45D7582024', 'E3725437-DB2B-4F42-886D-6C45D7582024', 4, 3.14, '2018-01-10', '2018-01-10 21:14:41', 0, 1, 'admin', '2018-01-10 21:15:05', 'admin', '2018-01-10 21:20:18'),(49, 'E3725437-DB2B-4F42-886D-6C45D7582025', 'E3725437-DB2B-4F42-886D-6C45D7582025-0001', 5, 0.14, '2018-01-11', '2018-01-11 21:16:05', 1, 1, 'admin', '2018-01-10 21:16:18', 'admin', '2018-01-10 21:19:23'),(53, 'E3725437-DB2B-4F42-886D-7C45D7582023', 'E3725437-DB2B-4F42-886D-6C45D7582023', 3, 3.00, '2018-01-10', '2018-01-10 22:20:22', 0, 1, 'admin', '2018-01-10 22:22:57', 'admin', '2018-01-10 22:23:05');
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`sample_bar` WRITE;
DELETE FROM `base`.`sample_bar`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`sample_detail` WRITE;
DELETE FROM `base`.`sample_detail`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`sample_foo` WRITE;
DELETE FROM `base`.`sample_foo`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`sample_foo_bar_relation` WRITE;
DELETE FROM `base`.`sample_foo_bar_relation`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`sys_config` WRITE;
DELETE FROM `base`.`sys_config`;
INSERT INTO `base`.`sys_config` (`id`,`cfg_code`,`cfg_type`,`cfg_name`,`cfg_value`,`cfg_group`,`is_deleted`,`cruser`,`crtime`,`mduser`,`mdtime`) VALUES (1, '6e1352df-2c9d-4811-8359-ac0d68e2291e', 1, '默认用户组', 'guest', 'admin', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(2, '292d8ffc-e394-49ce-8aba-71499f35fa55', 1, '默认角色', 'guest', 'admin', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(3, '34c10bf0-fe3b-4ff0-846d-66acf338e7fb', 1, '上传路径', '/usr/local/var/upload/cms', 'cms', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(4, 'd3cbc840-c8ca-4d39-ab60-e62535728338', 1, '上传域名', 'http://dl.com', 'cms', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(5, '76900565-ac11-4a9f-a990-1475db91db2f', 1, '开发者ID(AppID)', 'wx00979ffb52ef6c4f', 'wx', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(6, '8128125a-d95b-40cb-840e-477abfc594a7', 1, '开发者密码(AppSecret)', '27207dd6e1829bba98505740eac26820', 'wx', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(7, 'ccff1cec-a470-45bb-b6e3-313a62944978', 1, '服务器地址(URL)', 'http://smejr.gov.cn/wx', 'wx', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(8, '7f2dbe5c-d201-4225-a1d0-777f43c8f3bc', 1, '令牌(Token)', 'uW4FnzeSKkGtoLgPV8fwRvP041EFURDX', 'wx', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(9, '5e8e7c9f-b57d-45a3-9b50-828b0f0277d9', 1, '消息加解密密钥(EncodingAESKey)', '4AeBhntTAFgd3svDoAaxWeyaHJKbDs22kWecWrwgMwM', 'wx', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(10, 'eae604f8-bee4-484d-b44c-2affd4aeb47c', 1, '消息加解密方式(0/明文模式,1/兼容模式,2/安全模式)', '0', 'wx', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`sys_group` WRITE;
DELETE FROM `base`.`sys_group`;
INSERT INTO `base`.`sys_group` (`id`,`group_name`,`viewname`,`is_deleted`,`cruser`,`crtime`,`mduser`,`mdtime`) VALUES (1, 'admin', '管理员', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(2, 'user', '注册用户', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(3, 'guest', '游客', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`sys_permission` WRITE;
DELETE FROM `base`.`sys_permission`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`sys_role` WRITE;
DELETE FROM `base`.`sys_role`;
INSERT INTO `base`.`sys_role` (`id`,`role_name`,`viewname`,`is_deleted`,`cruser`,`crtime`,`mduser`,`mdtime`) VALUES (1, 'admin', '管理员', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(2, 'user', '注册用户', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(3, 'guest', '游客', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`sys_role_permission_relation` WRITE;
DELETE FROM `base`.`sys_role_permission_relation`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`sys_user` WRITE;
DELETE FROM `base`.`sys_user`;
INSERT INTO `base`.`sys_user` (`id`,`username`,`viewname`,`password`,`password_salt`,`email`,`is_disabled`,`is_locked`,`is_deleted`,`cruser`,`crtime`,`mduser`,`mdtime`) VALUES (1, 'admin', 'Admin', 'd39c172995e5e51bb9f2d30fee1c3fa09c7f26f15f8b991f629d7306a333ca388b5dbe807d571bc43442d549d71ae1335c3741cd8ae255be50b4c6e1a6d9fd93', 'ZuVQXbee', 'jrchens@126.com', 0, 0, 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(2, 'jason', 'Jason', 'efafe4276436b21d03b62a75495a9e632317baa0494ab423c6ba6a2119acef0026d04dd178eea3c3b967db04be71d7bc4631900cb6172dcfb835acd355ef789a', 'w0N3N6OL', 'jrchens@163.com', 0, 0, 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(3, 'mason', 'Mason', '35403eb3d9a683a86d09a5d6b964e22d0efe0907ed386c10ebee89c1a44e2ee00ff27c258607f2fb7c4a922daf1b29bfa3373986d8bbab6fb1f6527170a95e9f', 'sPxiGWxX', 'jrchens@foxmail.com', 0, 0, 0, 'admin', '2010-10-10 10:10:10', NULL, NULL);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`sys_user_group_relation` WRITE;
DELETE FROM `base`.`sys_user_group_relation`;
INSERT INTO `base`.`sys_user_group_relation` (`id`,`username`,`group_name`,`is_def`) VALUES (1, 'admin', 'admin', 1),(2, 'jason', 'user', 1),(3, 'mason', 'guest', 1);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`sys_user_role_relation` WRITE;
DELETE FROM `base`.`sys_user_role_relation`;
INSERT INTO `base`.`sys_user_role_relation` (`id`,`username`,`role_name`,`is_def`) VALUES (1, 'admin', 'admin', 1),(2, 'jason', 'user', 1),(3, 'mason', 'guest', 1);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`wx_access_token` WRITE;
DELETE FROM `base`.`wx_access_token`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`wx_area_info` WRITE;
DELETE FROM `base`.`wx_area_info`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`wx_jsapi_ticket` WRITE;
DELETE FROM `base`.`wx_jsapi_ticket`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`wx_menu` WRITE;
DELETE FROM `base`.`wx_menu`;
INSERT INTO `base`.`wx_menu` (`id`,`parent_id`,`node_type`,`node_name`,`node_key`,`node_url`,`node_media_id`,`node_appid`,`node_pagepath`,`view_scope`,`is_custom`,`menuid`,`rich_content`,`sort`,`url_state`,`is_deleted`,`cruser`,`crtime`,`mduser`,`mdtime`) VALUES (1, 0, 'root', '微信菜单', 'root', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 1, NULL, 0, 'admin', '2018-01-25 10:54:24', NULL, NULL);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`wx_menu_match_rule` WRITE;
DELETE FROM `base`.`wx_menu_match_rule`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`wx_tag` WRITE;
DELETE FROM `base`.`wx_tag`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`wx_user_info` WRITE;
DELETE FROM `base`.`wx_user_info`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`wx_user_info_tag_relation` WRITE;
DELETE FROM `base`.`wx_user_info_tag_relation`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `base`.`wx_web_access_token` WRITE;
DELETE FROM `base`.`wx_web_access_token`;
UNLOCK TABLES;
COMMIT;
