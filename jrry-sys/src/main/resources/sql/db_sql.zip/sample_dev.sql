/*
MySQL Backup
Database: sample_dev
Backup Time: 2018-03-10 22:12:59
*/

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS `jrhot_wx`.`cms_article`;
DROP TABLE IF EXISTS `jrhot_wx`.`cms_category`;
DROP TABLE IF EXISTS `jrhot_wx`.`cms_config`;
DROP TABLE IF EXISTS `jrhot_wx`.`cms_file`;
DROP TABLE IF EXISTS `jrhot_wx`.`sequence`;
DROP TABLE IF EXISTS `jrhot_wx`.`sys_group`;
DROP TABLE IF EXISTS `jrhot_wx`.`sys_permission`;
DROP TABLE IF EXISTS `jrhot_wx`.`sys_role`;
DROP TABLE IF EXISTS `jrhot_wx`.`sys_role_permission`;
DROP TABLE IF EXISTS `jrhot_wx`.`sys_user`;
DROP TABLE IF EXISTS `jrhot_wx`.`sys_user_group`;
DROP TABLE IF EXISTS `jrhot_wx`.`sys_user_role`;
DROP TABLE IF EXISTS `jrhot_wx`.`tbl_sample`;
DROP TABLE IF EXISTS `jrhot_wx`.`wx_access_token`;
DROP TABLE IF EXISTS `jrhot_wx`.`wx_config`;
DROP TABLE IF EXISTS `jrhot_wx`.`wx_menu`;
DROP TABLE IF EXISTS `jrhot_wx`.`wx_ticket`;
DROP TABLE IF EXISTS `jrhot_wx`.`wx_user_info`;
DROP TABLE IF EXISTS `jrhot_wx`.`wx_web_access_token`;
CREATE TABLE `cms_article` (
  `id` int(11) unsigned NOT NULL,
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0',
  `category_nodename` varchar(50) NOT NULL,
  `title` varchar(200) NOT NULL DEFAULT '',
  `summary` varchar(500) NOT NULL,
  `rich_content` text NOT NULL,
  `pub_date` date NOT NULL,
  `article_from` varchar(200) DEFAULT NULL,
  `article_editor` varchar(50) NOT NULL DEFAULT '',
  `state` int(4) unsigned NOT NULL DEFAULT '1',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `deleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cruser` varchar(32) NOT NULL DEFAULT '',
  `crtime` datetime NOT NULL,
  `mduser` varchar(32) DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNI_B7F137C91D72437C87BA1B46D8CACF15` (`title`) USING BTREE,
  KEY `IDX_FCA10EB72EC54A75B0757FE6B30D2A69` (`category_nodename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `cms_category` (
  `id` int(11) unsigned NOT NULL,
  `parent_id` int(11) unsigned NOT NULL,
  `nodename` varchar(50) NOT NULL DEFAULT '',
  `viewname` varchar(50) NOT NULL DEFAULT '',
  `node_link` varchar(200) DEFAULT NULL,
  `node_level` int(4) unsigned NOT NULL DEFAULT '1',
  `full_path` varchar(200) NOT NULL DEFAULT '',
  `state` int(4) unsigned NOT NULL DEFAULT '1',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `deleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cruser` varchar(32) NOT NULL DEFAULT '',
  `crtime` datetime NOT NULL,
  `mduser` varchar(32) DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNI_A2C265237A6F42019EA8492EB796B785` (`nodename`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `cms_config` (
  `config_code` varchar(50) NOT NULL DEFAULT '',
  `config_type` varchar(10) DEFAULT NULL,
  `config_label` varchar(50) DEFAULT NULL,
  `config_content` varchar(500) DEFAULT NULL,
  `config_value` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`config_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `cms_file` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `article_id` int(11) unsigned DEFAULT NULL,
  `original_file_name` varchar(200) NOT NULL,
  `file_name` varchar(200) NOT NULL DEFAULT '',
  `file_size` bigint(20) unsigned NOT NULL,
  `file_type` varchar(200) NOT NULL DEFAULT '',
  `relative_path` varchar(200) NOT NULL,
  `save_path` varchar(200) NOT NULL DEFAULT '',
  `file_sha1` varchar(40) NOT NULL,
  `owner` varchar(50) NOT NULL,
  `deleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cruser` varchar(50) NOT NULL DEFAULT '',
  `crtime` datetime NOT NULL,
  `mduser` varchar(50) DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
CREATE TABLE `sequence` (
  `id` bigint(20) unsigned DEFAULT NULL,
  `code` varchar(50) NOT NULL,
  PRIMARY KEY (`code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `sys_group` (
  `id` int(11) unsigned NOT NULL,
  `groupname` varchar(50) NOT NULL DEFAULT '',
  `viewname` varchar(50) NOT NULL DEFAULT '',
  `disabled` tinyint(1) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `cruser` varchar(50) NOT NULL DEFAULT '',
  `crtime` datetime NOT NULL,
  `mduser` varchar(50) DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uni_groupname` (`groupname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `sys_permission` (
  `id` int(11) unsigned NOT NULL,
  `pid` int(11) unsigned NOT NULL DEFAULT '0',
  `permission_code` varchar(200) NOT NULL,
  `viewname` varchar(50) NOT NULL DEFAULT '',
  `permission_content` varchar(500) NOT NULL,
  `disabled` tinyint(1) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `cruser` varchar(50) NOT NULL DEFAULT '',
  `crtime` datetime NOT NULL,
  `mduser` varchar(50) DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uni_5E1930AD6C184AC48C84A481DD4FCEA6` (`permission_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `sys_role` (
  `id` int(11) unsigned NOT NULL,
  `rolename` varchar(50) NOT NULL DEFAULT '',
  `viewname` varchar(50) NOT NULL DEFAULT '',
  `disabled` tinyint(1) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `cruser` varchar(50) NOT NULL DEFAULT '',
  `crtime` datetime NOT NULL,
  `mduser` varchar(50) DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uni_rolename` (`rolename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `sys_role_permission` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rolename` varchar(50) NOT NULL DEFAULT '',
  `permission_code` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
CREATE TABLE `sys_user` (
  `id` int(11) unsigned NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL DEFAULT '',
  `viewname` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(200) NOT NULL DEFAULT '',
  `password_salt` varchar(50) NOT NULL DEFAULT '',
  `groupname` varchar(50) NOT NULL,
  `rolename` varchar(50) NOT NULL,
  `state` int(4) NOT NULL DEFAULT '1',
  `disabled` tinyint(1) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `cruser` varchar(50) NOT NULL DEFAULT '',
  `crtime` datetime NOT NULL,
  `mduser` varchar(50) DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNI_B096EAC8FE0F45ECA98F7070FCB7D196` (`username`),
  UNIQUE KEY `UNI_143F0E95BBE34CBE84351FD75847465E` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `sys_user_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL DEFAULT '',
  `groupname` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;
CREATE TABLE `sys_user_role` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL DEFAULT '',
  `rolename` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;
CREATE TABLE `tbl_sample` (
  `id` int(11) unsigned NOT NULL,
  `username` varchar(32) NOT NULL DEFAULT '',
  `viewname` varchar(32) NOT NULL DEFAULT '',
  `password` varchar(128) NOT NULL DEFAULT '',
  `password_salt` varchar(32) NOT NULL DEFAULT '',
  `state` int(4) unsigned NOT NULL DEFAULT '1',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `deleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cruser` varchar(32) NOT NULL DEFAULT '',
  `crtime` datetime NOT NULL,
  `mduser` varchar(32) DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uni_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `wx_access_token` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `access_token` varchar(200) DEFAULT NULL,
  `expires_in` int(4) DEFAULT NULL,
  `expires_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
CREATE TABLE `wx_config` (
  `config_code` varchar(50) NOT NULL DEFAULT '',
  `config_type` varchar(10) DEFAULT NULL,
  `config_label` varchar(50) DEFAULT NULL,
  `config_content` varchar(500) DEFAULT NULL,
  `config_value` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`config_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `wx_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0',
  `srt` int(11) unsigned DEFAULT '1',
  `node_type` varchar(50) DEFAULT NULL,
  `node_name` varchar(50) DEFAULT NULL,
  `node_key` varchar(50) DEFAULT NULL,
  `node_url` varchar(200) DEFAULT NULL,
  `node_media_id` varchar(50) DEFAULT NULL,
  `node_appid` varchar(50) DEFAULT NULL,
  `node_pagepath` varchar(200) DEFAULT NULL,
  `rich_content` text,
  `deleted` tinyint(1) unsigned DEFAULT '0',
  `cruser` varchar(50) DEFAULT NULL,
  `crtime` datetime DEFAULT NULL,
  `mduser` varchar(50) DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
CREATE TABLE `wx_ticket` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ticket` varchar(200) DEFAULT NULL,
  `expires_in` int(4) DEFAULT NULL,
  `expires_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
CREATE TABLE `wx_user_info` (
  `openid` varchar(50) NOT NULL DEFAULT '',
  `viewname` varchar(50) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `nickname` varchar(50) DEFAULT NULL,
  `sex` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `headimgurl` varchar(500) DEFAULT NULL,
  `privilege` text,
  `unionid` varchar(50) DEFAULT NULL,
  `cruser` varchar(50) DEFAULT NULL,
  `crtime` datetime DEFAULT NULL,
  `mduser` varchar(50) DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`openid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `wx_web_access_token` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `access_token` varchar(200) DEFAULT NULL,
  `expires_in` int(4) DEFAULT NULL,
  `expires_time` datetime DEFAULT NULL,
  `openid` varchar(100) DEFAULT NULL,
  `refresh_token` varchar(200) DEFAULT NULL,
  `scope` varchar(50) DEFAULT NULL,
  `ticket` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
BEGIN;
LOCK TABLES `jrhot_wx`.`cms_article` WRITE;
DELETE FROM `jrhot_wx`.`cms_article`;
INSERT INTO `jrhot_wx`.`cms_article` (`id`,`parent_id`,`category_nodename`,`title`,`summary`,`rich_content`,`pub_date`,`article_from`,`article_editor`,`state`,`disabled`,`deleted`,`cruser`,`crtime`,`mduser`,`mdtime`) VALUES (11, 0, 'news', '途欢健康', '途欢健康、协同于现有的医疗服务体系，致力于构建更精准的医疗保健模式', '', '2017-09-14', '新闻', '新闻', 0, 0, 0, 'admin', '2017-09-09 10:03:06', 'admin', '2017-09-27 12:26:07'),(15, 0, 'news', 'Google-NULL', 'Google', '<p><img src=\"../1504922431.jpg\" alt=\"1504922431\" width=\"200\" height=\"133\" /></p>', '2017-09-09', 'Google', 'Google', 1, 0, 0, 'admin', '2017-09-09 11:17:14', 'admin', '2017-09-09 11:37:20'),(16, 0, 'news', 'Google﻿', 'Google﻿', '<p><a href=\"https://www.google.com.hk\" target=\"_blank\" rel=\"noopener\"><span style=\"color: #c41a16; font-family: Menlo, monospace; font-size: 12px; white-space: pre;\">Google</span></a></p>\n<p>&nbsp;</p>\n<p><span style=\"color: #c41a16; font-family: Menlo, monospace; font-size: 12px; white-space: pre;\"><img src=\"../1504922431.jpg\" alt=\"\" width=\"100\" height=\"67\" /></span></p>', '2017-09-09', 'Google﻿', 'Google﻿', 1, 0, 0, 'admin', '2017-09-09 11:26:28', NULL, NULL);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`cms_category` WRITE;
DELETE FROM `jrhot_wx`.`cms_category`;
INSERT INTO `jrhot_wx`.`cms_category` (`id`,`parent_id`,`nodename`,`viewname`,`node_link`,`node_level`,`full_path`,`state`,`disabled`,`deleted`,`cruser`,`crtime`,`mduser`,`mdtime`) VALUES (1, 0, 'cms_category', '类别管理', NULL, 1, '/1', 1, 0, 0, 'admin', '2017-09-08 11:10:01', NULL, NULL),(12, 1, 'news', '新闻', '', 2, '/1/12', 1, 0, 0, 'admin', '2017-09-08 11:14:48', 'admin', '2017-09-21 10:37:11'),(13, 1, 'pic', '图片', '', 2, '/1/13', 1, 0, 0, 'admin', '2017-09-08 11:16:17', NULL, NULL),(21, 1, 'about-us', '关于我们', '', 2, '/1/21', 1, 0, 0, 'admin', '2017-09-21 10:29:58', NULL, NULL);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`cms_config` WRITE;
DELETE FROM `jrhot_wx`.`cms_config`;
INSERT INTO `jrhot_wx`.`cms_config` (`config_code`,`config_type`,`config_label`,`config_content`,`config_value`) VALUES ('3D92034B19CA47159ABB17CEB8BBE27E', 'text', '网站关键字', NULL, '华大天益,华大,天益'),('86E05B8534F1458AAF91ACC20DA4A514', 'text', '网站名称', NULL, 'hdtyi.com'),('A4FEB6514349407DA75C5D058F2B530C', 'text', '网站作者', NULL, 'hdtyi.com'),('A5A56749A006433A9EA7D866404DA7ED', 'textarea', '联系方式', NULL, '邮编：212400; 地址：句容市经济开发区福地西路9号; 电话：0511-80780357\n\n邮编：212400; 地址：句容市经济开发区福地西路9号; 电话：0511-80780357\n\n'),('CED3B5A318124202852515BA94FBF13E', 'textarea', '网站说明', NULL, '江苏华大天益电力科技有限公司于2011年08月02日在句容市市场监督管理局登记成立。法定代表人董靖，公司经营范围包括电力新技术研发及成果推广；软件开发；信息系统集成服务等。');
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`cms_file` WRITE;
DELETE FROM `jrhot_wx`.`cms_file`;
INSERT INTO `jrhot_wx`.`cms_file` (`id`,`article_id`,`original_file_name`,`file_name`,`file_size`,`file_type`,`relative_path`,`save_path`,`file_sha1`,`owner`,`deleted`,`cruser`,`crtime`,`mduser`,`mdtime`) VALUES (1, NULL, '1207国统第四次课件.pdf', '33d6c5a3-5713-4afc-bddc-8de626d9f481.pdf', 758991, 'application/pdf', '/2017/09/20', '/usr/local/var/upload/2017/09/20', 'cf6f2e99b709b1eee2b1aec5ae63c35c828c3ad1', 'admin', 0, 'admin', '2017-09-20 17:21:05', NULL, NULL),(2, NULL, '20151130国统第二章.ppt', '5cfb67ac-4453-41f4-a4c7-89899fbb7b98.ppt', 2344960, 'application/vnd.ms-powerpoint', '/2017/09/20', '/usr/local/var/upload/2017/09/20', 'bd98e873f4453a5d13426e9a5700c03b70e60f7c', 'admin', 0, 'admin', '2017-09-20 17:21:05', NULL, NULL);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`sequence` WRITE;
DELETE FROM `jrhot_wx`.`sequence`;
INSERT INTO `jrhot_wx`.`sequence` (`id`,`code`) VALUES (30, 'cms'),(30, 'sys');
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`sys_group` WRITE;
DELETE FROM `jrhot_wx`.`sys_group`;
INSERT INTO `jrhot_wx`.`sys_group` (`id`,`groupname`,`viewname`,`disabled`,`deleted`,`cruser`,`crtime`,`mduser`,`mdtime`) VALUES (2, 'root', '超级管理员', 0, 0, 'root', '1982-08-11 06:22:00', 'admin', '2017-09-05 11:02:57'),(1301, 'admin', '管理员', 0, 0, 'jrchens', '2017-08-26 08:26:06', 'admin', '2017-09-05 09:48:04'),(1401, 'manager', '管理员', 0, 1, 'jrchens', '2017-08-26 08:27:12', 'admin', '2017-09-21 15:02:30'),(2401, 'sys', '系统管理员', 0, 0, 'admin', '2017-09-04 14:54:32', 'admin', '2017-09-04 14:54:46'),(2402, 'system', '管理员', 0, 1, 'admin', '2017-09-04 14:55:17', 'admin', '2017-09-04 14:55:52'),(3018, 'user', '用户', 0, 0, 'admin', '2017-09-06 22:11:32', NULL, NULL);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`sys_permission` WRITE;
DELETE FROM `jrhot_wx`.`sys_permission`;
INSERT INTO `jrhot_wx`.`sys_permission` (`id`,`pid`,`permission_code`,`viewname`,`permission_content`,`disabled`,`deleted`,`cruser`,`crtime`,`mduser`,`mdtime`) VALUES (4, 0, 'permission', '权限管理', '', 0, 0, 'root', '1982-08-11 06:22:00', NULL, NULL),(5, 4, 'cms', '内容管理', '', 0, 0, 'root', '1982-08-11 06:22:00', NULL, NULL),(6, 5, 'cms:category:index', '类别管理', 'cms:category:index', 0, 0, 'root', '1982-08-11 06:22:00', 'admin', '2017-09-21 14:55:32'),(26, 5, 'cms:file:index', '附件管理', 'cms:file:index', 0, 0, 'admin', '2017-09-21 14:54:47', NULL, NULL),(27, 5, 'cms:article:index', '文章管理', 'cms:article:index', 0, 0, 'admin', '2017-09-21 14:55:25', NULL, NULL),(28, 5, 'cms:config:index', '配置管理', 'cms:config:index', 0, 0, 'admin', '2017-09-21 14:56:04', NULL, NULL),(3008, 4, 'sys', '系统管理', 'javascript:;', 0, 0, 'admin', '2017-09-06 10:46:27', NULL, NULL),(3009, 3008, 'user', '用户管理', 'javascript:;', 0, 0, 'admin', '2017-09-06 10:46:51', NULL, NULL),(3010, 3008, 'group', '群组管理', 'javascript::', 0, 0, 'admin', '2017-09-06 10:47:13', NULL, NULL),(3011, 3008, 'role', '角色管理', 'javascript::', 0, 0, 'admin', '2017-09-06 10:47:34', NULL, NULL),(3013, 3008, 'permission_manager', '权限管理', 'javascript:;', 0, 0, 'admin', '2017-09-06 10:48:22', 'admin', '2017-09-21 14:52:55'),(3015, 3008, 'role_permission', '授权管理', 'javascript:;', 0, 0, 'admin', '2017-09-06 16:37:26', NULL, NULL);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`sys_role` WRITE;
DELETE FROM `jrhot_wx`.`sys_role`;
INSERT INTO `jrhot_wx`.`sys_role` (`id`,`rolename`,`viewname`,`disabled`,`deleted`,`cruser`,`crtime`,`mduser`,`mdtime`) VALUES (3, 'root', '超级管理员', 0, 0, 'root', '1982-08-11 06:22:00', 'root', '2017-08-30 16:06:49'),(10, 'ROLE_GENERAL_MANAGER', '总经理', 1, 0, 'root', '1982-08-11 06:22:00', 'admin', '2017-09-06 16:27:54'),(11, 'ROLE_ASSISTANT_GENERAL_MANAGER', '总经理助理', 0, 0, 'root', '1982-08-11 06:22:00', 'admin', '2017-09-05 09:48:12'),(12, 'ROLE_SALES_MANAGER', '销售经理', 0, 0, 'root', '1982-08-11 06:22:00', 'admin', '2017-09-05 10:32:12'),(13, 'ROLE_SALESPERSON', '销售专员', 0, 0, 'root', '1982-08-11 06:22:00', 'admin', '2017-09-21 15:02:50'),(14, 'ROLE_FINANCIAL_MANAGER', '财务经理', 0, 0, 'root', '1982-08-11 06:22:00', NULL, NULL),(15, 'ROLE_FINANCIAL_ACCOUNTING', '财务会计', 0, 0, 'root', '1982-08-11 06:22:00', NULL, NULL),(16, 'ROLE_FINANCIAL_CASHIER', '财务出纳', 0, 0, 'root', '1982-08-11 06:22:00', NULL, NULL),(17, 'ROLE_PURCHASING_MANAGER', '采购经理', 0, 0, 'root', '1982-08-11 06:22:00', NULL, NULL),(18, 'ROLE_PROCUREMENT_COMMISSIONER', '采购专员', 0, 0, 'root', '1982-08-11 06:22:00', NULL, NULL),(19, 'ROLE_PERSONNEL_MANAGER', '人事经理', 0, 0, 'root', '1982-08-11 06:22:00', NULL, NULL),(20, 'ROLE_PERSONNEL_COMMISSIONER', '人事专员', 0, 0, 'root', '1982-08-11 06:22:00', NULL, NULL),(21, 'ROLE_LIBRARY_MANAGEMENT', '库管', 0, 0, 'root', '1982-08-11 06:22:00', NULL, NULL),(2501, 'ROLE_USER', '用户', 0, 0, 'admin', '2017-09-04 16:33:51', 'admin', '2017-09-04 16:34:11'),(3016, 'ROLE_ADMIN', '管理员', 0, 0, 'admin', '2017-09-06 22:10:05', NULL, NULL);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`sys_role_permission` WRITE;
DELETE FROM `jrhot_wx`.`sys_role_permission`;
INSERT INTO `jrhot_wx`.`sys_role_permission` (`id`,`rolename`,`permission_code`) VALUES (1, 'root', 'cms'),(2, 'root', 'cms:category:index'),(3, 'root', 'cms:file:index'),(4, 'root', 'cms:article:index'),(5, 'root', 'cms:config:index'),(6, 'root', 'sys'),(7, 'root', 'user'),(8, 'root', 'group'),(9, 'root', 'role'),(10, 'root', 'permission_manager'),(11, 'root', 'role_permission'),(12, 'ROLE_USER', 'cms:article:index'),(13, 'ROLE_USER', 'cms:file:index'),(14, 'ROLE_ADMIN', 'cms'),(15, 'ROLE_ADMIN', 'cms:category:index'),(16, 'ROLE_ADMIN', 'cms:file:index'),(17, 'ROLE_ADMIN', 'cms:article:index'),(18, 'ROLE_ADMIN', 'cms:config:index');
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`sys_user` WRITE;
DELETE FROM `jrhot_wx`.`sys_user`;
INSERT INTO `jrhot_wx`.`sys_user` (`id`,`email`,`username`,`viewname`,`password`,`password_salt`,`groupname`,`rolename`,`state`,`disabled`,`deleted`,`cruser`,`crtime`,`mduser`,`mdtime`) VALUES (1, 'jrfgw@hotmail.com', 'jrfgw', '市发改经信委', 'ba3253876aed6bc22d4a6ff53d8406c6ad864195ed144ab5c87621b6c233b548baeae6956df346ec8c17f5ea10f35ee3cbc514797ed7ddd3145464e2a0bab413', '', 'sys', 'ROLE_USER', 1, 0, 1, '', '2017-08-31 16:42:37', 'admin', '2017-08-31 17:40:24'),(2, 'jrnw@hotmail.com', 'jrnw', '市农委', 'a33225f019bcec4915853d8179538da09feeafd68086ec561c40fde23f53b8d0', 'Hfv5-mocnLC0XNAe', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'admin', '2017-09-06 22:06:17'),(3, 'jrczj@hotmail.com', 'jrczj', '市财政局', 'ba3253876aed6bc22d4a6ff53d8406c6ad864195ed144ab5c87621b6c233b548baeae6956df346ec8c17f5ea10f35ee3cbc514797ed7ddd3145464e2a0bab413', '', 'sys', 'ROLE_USER', 1, 0, 1, '', '2017-08-31 16:42:37', 'admin', '2017-08-31 22:35:34'),(4, 'jrscjgj@hotmail.com', 'jrscjgj', '市市场监管局', '03cc4503d4f037693c76b2ab2858d105fbd8ad31e471423267b62e6ad4361464', '0nxRZWlQ_a4Mid2J', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'admin', '2017-09-05 14:23:23'),(5, 'jrajj@hotmail.com', 'jrajj', '市安监局', 'bc7ddac0900c49bb147c0c560af9489468c1b561c3d88c276eacf8a9d6762ad2', '5w7UdMWjCA12Ixjn', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:32'),(6, 'jrrsj@hotmail.com', 'jrrsj', '市人社局', '37c16b7e1c4bd39505dfbc00f00082a0385b75365b5912a08bedad8ac95b16a0', '07Su4IXKtTOWYuKY', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'admin', '2017-09-06 22:06:03'),(7, 'jrzjj@hotmail.com', 'jrzjj', '市住建局', '5fc87d036ba6a1348df966f8727f5e1f537d9ff5e51996933665d9e2ee088001', '7DQokWS0wsx4tMRP', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:32'),(8, 'jrkjj@hotmail.com', 'jrkjj', '市科技局', 'ea8288f1690bb698add3bd161e469144cd36200a18b0e2d9d36e8103c091ed47', 'AwVZkJJ3ohPLf_S_', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:32'),(9, 'jrjyj@hotmail.com', 'jrjyj', '市教育局', 'c0c57bcf1a8c479919bf18b9d49306ebcc4cadec9ceee72d65e88c21330597ae', 'oJZyT8elPokZV8k1', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:32'),(10, 'jrwjw@hotmail.com', 'jrwjw', '市卫计委', 'ee32433b6c6badca0555fa20fb94ee224193447d8bceb0bc41798ed07c918ae1', 'dLGG7cywKMUSBaQQ', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:32'),(11, 'jrswj@hotmail.com', 'jrswj', '市商务局', '72783155375d0f0a4202fccf3b30d5b25cd9995a6888c37ebb221901b5f844c8', 'jkrC1F3EZwjbupCb', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:32'),(12, 'jrjtysj@hotmail.com', 'jrjtysj', '市交通运输局', '58c9c812c5065472dd360f5cab4f10270687e905f27cda0f87b887ec3b29c21e', 'fu_rEiCd40pVEbgC', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:32'),(13, 'jrwgtyj@hotmail.com', 'jrwgtyj', '市文广体育局', 'dd48d13e3b2d70b74e24931bb6076dd450711cf37bbb04f7ae197706a84c98b0', 'sS27IXEBqBIttscd', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(14, 'jrmzj@hotmail.com', 'jrmzj', '市民政局', '0eda95216f9adcbbc944f59589f5fe1ad020d7f5f624d3a5eb8cc12680f27f4d', 'vLlo-matBRHflKtn', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(15, 'jrhbj@hotmail.com', 'jrhbj', '市环保局', '28c6cdc71522569046ada98f243c1904c18f28f297eb631f44af7f5547e53da8', 'aCnJOyrGtj5ZP5Za', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(16, 'jrsfj@hotmail.com', 'jrsfj', '市司法局', '7ea99f0cb61cd9ca46342cfc3cd36ba3cd6b51cf1e831d19f053b33e2579f4f1', 'IiVdQD7ywv7gCie7', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(17, 'jrwjj@hotmail.com', 'jrwjj', '市物价局', '80e76ae54d2ed7bed95bcf59d2a221e41b1b629a9edf8cc07104d7d16f2dfce8', 'NdjVBA9UUifP2Lbh', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(18, 'jrrmyh@hotmail.com', 'jrrmyh', '人行句容支行', '313c40462924c393063f91b6666ab45e713e62d0ffea4962befa3bc31dde3ff8', 'yGVCxMeL1d4ka0Vt', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(19, 'jrgsj@hotmail.com', 'jrgsj', '市国税局', 'ee4eb03d8a6ab31aa88d53178891b291f6d4c9b2df159605737f16b63504eb51', 'yh7WVAFCNMP6H544', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(20, 'jrdsj@hotmail.com', 'jrdsj', '市地税局', '0e90bc2f1d16908bd2763abd74d19ef7d3e3547b720660c2466d9ccaad5ebe2a', 'Qm47NcaFGIE5BmY6', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(21, 'jrtjj@hotmail.com', 'jrtjj', '市统计局', 'ec17725b4c294e5887dabb60bfe64d6f0f6cd97108a74b04b11edb212371f385', 'Ivg3GR_RuLojOTfB', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(22, 'jrsjj@hotmail.com', 'jrsjj', '市审计局', '57c587df168351ad7be405976128f45bf09956e0cff1fa913c5d1723fdee5040', 'U7XLt5vg6kl3NawM', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(23, 'jrslnjj@hotmail.com', 'jrslnjj', '市水利农机局', '392f68d5bbaa458c1d15d1a43dafb647d54a0244a949b8c765eddffdf2eb04b6', 'F4-SOSUjVkEz6r_G', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(24, 'jrcgj@hotmail.com', 'jrcgj', '市城管局', '8c878f4bbbdbe054c8c53f14a164f487de4e11dba2f1cb1c8252d65fc4ba77ce', 'wSp4o5soMBK8NI6R', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(25, 'jrgtj@hotmail.com', 'jrgtj', '市国土局', '7968f785c5daf917eb4922766cf652eddd20ba3cc77ce2c3aa5262bb7c73b4df', 'nBrx_lsAe-jQu0HV', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(26, 'jrghj@hotmail.com', 'jrghj', '市规划局', 'de051d70fb0b2b0580445d01003e5c8f19335490e634661b37c50dac4daf154e', 'mz0L3JDIv-Vp-BvM', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(27, 'jrmzswj@hotmail.com', 'jrmzswj', '市民宗事务局（旅游局）', 'b5d70fb6e07ed398a30aacb0af3bc4f9f6bb7541388b0837551b9aed4b74191f', 'R_zSyrUteuEnNir7', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(28, 'jrfy@hotmail.com', 'jrfy', '市法院', 'a2fe72bb7d1ed355137b8535af5d5c7e46ec58239b6375f82c929dd4aaf89061', 'zaIxWYSwLwFqrwrA', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(29, 'jrjcy@hotmail.com', 'jrjcy', '市检察院', 'dfdc342de912a1563cc5ecafaac43b3a4fd2678d97c92d44876eaf9ece6e76df', 'a5CljgQx9yeyBlLA', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(30, 'jrgaj@hotmail.com', 'jrgaj', '市公安局', '656184ce8ca508038da505cf691a64a35ff2afaf36edc6fff0382c252e5be848', 'QzkskLZcVLEC8UL-', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(31, 'jrggzyjyzx@hotmail.com', 'jrggzyjyzx', '句容市公共资源交易中心', 'ef1c69509b01459ae0e7715afa5cafea44f52ba8330b04ae29738ea43e1ef3ef', '6xBe6Ja9w9PTnp79', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(32, 'jrzlszgs@hotmail.com', 'jrzlszgs', '句容市自来水总公司', '6498515767a8d6584e1fc519559de77b1caebd464da68bdc2eea6c4d80b54e58', 'f4QehCkOiFWknwVv', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(33, 'jrswjt@hotmail.com', 'jrswjt', '句容市水务集团', 'e01a41ef0822e98cb675f6c54c410aad9323613a5fa7d50561e6f382b01bd609', '7Hzs4Zsoom7MB2Wr', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(34, 'jrgdgs@hotmail.com', 'jrgdgs', '句容市供电公司', '35c63833b20fb0e8a15c88874716ba4d205960b4ae1c2f0e256911fb5a1a1b73', 'o2i_Lo6V0VKMcGzC', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(35, 'jrhrrq@hotmail.com', 'jrhrrq', '句容华润燃气有限公司', '39268adf16d7cc060ac5d9b575f52f4bc8d070d9f0380b0dfe8d178fda263398', 'P02H4dJ7Kw6VwWle', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(36, 'jrydgs@hotmail.com', 'jrydgs', '中国移动句容分公司', '358a9b44cf4867f19391dc565f7e9d861099eec37367b0b37fff1355080e21fb', '2oIZqd0TELWEtufh', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(37, 'jrdxgs@hotmail.com', 'jrdxgs', '中国电信句容分公司', '3422a4c2878ccdf620597238f53cf48478319df45ca6f272ead0049449321020', '7eYMcaoarTReuijC', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(39, 'jrscjgj1@hotmail.com', 'jrscjgj1', '市市场监管局', '85cacc7b85ee8c445aba930f63910273897fe2bd26267b496e66781eb00211dc', 'ODfS1htptQj7MBCk', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(40, 'jrscjgj2@hotmail.com', 'jrscjgj2', '市市场监管局', '635a421ecdf2a91266abfb2e9b2d03e2c278a10501407aaf578294cb8d730261', '5Dnhaj1fuqIJvNG4', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(41, 'zjsj@hotmail.com', 'zjsj', '镇江数据', '366b079e8d4d7df442c2031aab3f481df7c118733c0d3597c72ce5fb80f7177c', 'ap8nla4X05bh7O47', 'sys', 'ROLE_USER', 1, 0, 0, '', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(1000, 'root@hotmail.com', 'root', '超级管理员', '8b48992f195edb15e5f95b212f4d6856c648f813d656590f4d0e1e206f0102e4', 'P8XY4yco-FoIa5KQ', 'sys', 'ROLE_USER', 1, 0, 0, 'root', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(1801, 'jrchens@hotmail.com', 'jrchens', 'JRCHENS', 'f693ce23ee634910aeded8c9616f7a74bf8533ce3eec484a5872f002524ff014', 'gAdN3T_IeGhAPSti', 'sys', 'ROLE_USER', 1, 0, 0, 'jrchens', '2017-08-31 16:42:37', 'jrchens', '2017-09-02 22:03:33'),(1901, 'admin@hotmail.com', 'admin', 'ADMIN', '7a8681121758eec7f23e4c8eeb17d8d443450626b4d8367674f0d7009090342f', 'z-AkE5mxUSD9wOgQ', 'admin', 'ROLE_ADMIN', 1, 0, 0, 'jrchens', '2017-08-31 16:42:37', 'admin', '2017-09-21 15:03:17'),(2201, 'jrchens@163.com', 'jason', '杰森', 'f36bb8f194572ec6a516ba364db20227f33a01107779682ccd6689cd27fe4d0c', 'IYNk8EeNwW0oi7l-', 'user', 'ROLE_USER', 1, 0, 0, 'admin', '2017-08-31 17:08:27', 'admin', '2017-09-21 15:03:53'),(2203, 'jrchens@gmail.com', 'chensheng', '陈盛', '0480bb7fdecd741eed7e9bae6ec0809205c08b6f3777999a0cbe0443f1dcf472', 'tyUN889WloLG0SnM', 'sys', 'ROLE_USER', 1, 0, 1, 'admin', '2017-08-31 17:13:47', 'admin', '2017-09-21 15:02:02'),(2301, 'simple.life.cs@gmail.com', 'simple.life.cs', 'SimpleLifeCS', '292230be7c7b98bf6675efd0fabb8b27ff27620836ef6222428dbc8c72b0be03', 'trgw2kHlfhyCAzXa', 'sys', 'ROLE_USER', 1, 0, 1, 'admin', '2017-09-02 11:10:27', 'admin', '2017-09-21 15:01:53'),(2302, 'alex@gmail.com', 'alex', '亚历克斯', '81c860cb3e3494d2dac4ceb795695bfb94fde143b1d2426c37071403337654ff', 'E26Qeatf3aGetZj_', 'sys', 'ROLE_USER', 1, 0, 1, 'simple.life.cs', '2017-09-02 11:13:56', 'admin', '2017-09-21 15:01:51'),(2303, 'jrchensh@hotmail.com', 'jrchensheng', 'JRChenSheng', '442f2c4b90155569f88e17d0b6b7aaaf5ea650ecea7e9c372ad8fb5ce59d5cbf', 'i1xKTvYOmqPNIq0e', 'sys', 'ROLE_USER', 1, 0, 1, 'null', '2017-09-02 12:06:58', 'admin', '2017-09-21 15:01:45'),(2304, 'dsafdsaf', 'fdsafas', 'fdsa', '9f12cd875418629157d071514b63d60c2c4a864315c0785cc70df68e64b50c92', '3EKAdinJsu8tXOk_', 'sys', 'ROLE_USER', 1, 0, 1, 'null', '2017-09-02 12:08:36', 'admin', '2017-09-05 10:59:05'),(2502, 'simple.life.cs@gmail.cn', 'SimpleLife', 'SimpeLife', 'ea30c4aad882f238b43e77f2fd09852a6ada8c2385797e4d6caab9450f7808d4', '-{qB[$1/aSC?XS>s', 'sys', 'ROLE_USER', 1, 0, 1, 'admin', '2017-09-04 16:47:53', 'admin', '2017-09-21 15:01:43'),(2702, 'jrchenshyahoo@email.com', 'jrchenshyahoo', 'jrchenshyahoo', '850a36f1e0bbece813fd74b187b2ce7659e7924b08b4a48216ae3f22b6f867d3', '>[CqD*{pL<RhC.^L', 'sys', 'ROLE_USER', 1, 0, 1, 'admin', '2017-09-05 09:43:06', 'admin', '2017-09-21 15:01:40'),(2703, 'jrche@gmailc.om', 'jrche', 'jrche', '5a7c2346e7273853e31ed8edaacbcee6c79baedccc5022cfeded95b546176b8a', 'iC,XB_3$Aqa(qf;l', 'sys', 'ROLE_USER', 1, 0, 1, 'admin', '2017-09-05 10:05:47', 'admin', '2017-09-21 15:01:36');
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`sys_user_group` WRITE;
DELETE FROM `jrhot_wx`.`sys_user_group`;
INSERT INTO `jrhot_wx`.`sys_user_group` (`id`,`username`,`groupname`) VALUES (1, 'jrfgw', 'sys'),(2, 'jrnw', 'sys'),(3, 'jrczj', 'sys'),(4, 'jrscjgj', 'sys'),(5, 'jrajj', 'sys'),(6, 'jrrsj', 'sys'),(7, 'jrzjj', 'sys'),(8, 'jrkjj', 'sys'),(9, 'jrjyj', 'sys'),(10, 'jrwjw', 'sys'),(11, 'jrswj', 'sys'),(12, 'jrjtysj', 'sys'),(13, 'jrwgtyj', 'sys'),(14, 'jrmzj', 'sys'),(15, 'jrhbj', 'sys'),(16, 'jrsfj', 'sys'),(17, 'jrwjj', 'sys'),(18, 'jrrmyh', 'sys'),(19, 'jrgsj', 'sys'),(20, 'jrdsj', 'sys'),(21, 'jrtjj', 'sys'),(22, 'jrsjj', 'sys'),(23, 'jrslnjj', 'sys'),(24, 'jrcgj', 'sys'),(25, 'jrgtj', 'sys'),(26, 'jrghj', 'sys'),(27, 'jrmzswj', 'sys'),(28, 'jrfy', 'sys'),(29, 'jrjcy', 'sys'),(30, 'jrgaj', 'sys'),(31, 'jrggzyjyzx', 'sys'),(32, 'jrzlszgs', 'sys'),(33, 'jrswjt', 'sys'),(34, 'jrgdgs', 'sys'),(35, 'jrhrrq', 'sys'),(36, 'jrydgs', 'sys'),(37, 'jrdxgs', 'sys'),(38, 'jrscjgj1', 'sys'),(39, 'jrscjgj2', 'sys'),(40, 'zjsj', 'sys'),(41, 'root', 'sys'),(42, 'jrchens', 'sys'),(49, 'fdsafas', 'sys'),(53, 'jason', 'user'),(54, 'admin', 'admin');
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`sys_user_role` WRITE;
DELETE FROM `jrhot_wx`.`sys_user_role`;
INSERT INTO `jrhot_wx`.`sys_user_role` (`id`,`username`,`rolename`) VALUES (1, 'jrfgw', 'ROLE_USER'),(2, 'jrnw', 'ROLE_USER'),(3, 'jrczj', 'ROLE_USER'),(4, 'jrscjgj', 'ROLE_USER'),(5, 'jrajj', 'ROLE_USER'),(6, 'jrrsj', 'ROLE_USER'),(7, 'jrzjj', 'ROLE_USER'),(8, 'jrkjj', 'ROLE_USER'),(9, 'jrjyj', 'ROLE_USER'),(10, 'jrwjw', 'ROLE_USER'),(11, 'jrswj', 'ROLE_USER'),(12, 'jrjtysj', 'ROLE_USER'),(13, 'jrwgtyj', 'ROLE_USER'),(14, 'jrmzj', 'ROLE_USER'),(15, 'jrhbj', 'ROLE_USER'),(16, 'jrsfj', 'ROLE_USER'),(17, 'jrwjj', 'ROLE_USER'),(18, 'jrrmyh', 'ROLE_USER'),(19, 'jrgsj', 'ROLE_USER'),(20, 'jrdsj', 'ROLE_USER'),(21, 'jrtjj', 'ROLE_USER'),(22, 'jrsjj', 'ROLE_USER'),(23, 'jrslnjj', 'ROLE_USER'),(24, 'jrcgj', 'ROLE_USER'),(25, 'jrgtj', 'ROLE_USER'),(26, 'jrghj', 'ROLE_USER'),(27, 'jrmzswj', 'ROLE_USER'),(28, 'jrfy', 'ROLE_USER'),(29, 'jrjcy', 'ROLE_USER'),(30, 'jrgaj', 'ROLE_USER'),(31, 'jrggzyjyzx', 'ROLE_USER'),(32, 'jrzlszgs', 'ROLE_USER'),(33, 'jrswjt', 'ROLE_USER'),(34, 'jrgdgs', 'ROLE_USER'),(35, 'jrhrrq', 'ROLE_USER'),(36, 'jrydgs', 'ROLE_USER'),(37, 'jrdxgs', 'ROLE_USER'),(38, 'jrscjgj1', 'ROLE_USER'),(39, 'jrscjgj2', 'ROLE_USER'),(40, 'zjsj', 'ROLE_USER'),(41, 'root', 'ROLE_USER'),(42, 'jrchens', 'ROLE_USER'),(44, 'jason', 'ROLE_USER'),(49, 'fdsafas', 'ROLE_USER'),(54, 'admin', 'ROLE_ADMIN');
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`tbl_sample` WRITE;
DELETE FROM `jrhot_wx`.`tbl_sample`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`wx_access_token` WRITE;
DELETE FROM `jrhot_wx`.`wx_access_token`;
INSERT INTO `jrhot_wx`.`wx_access_token` (`id`,`access_token`,`expires_in`,`expires_time`) VALUES (1, '6SEk4z7Dax1YpVF9RJWNOZBT_-yUoZmbhKgsecyA0TPYXZymb-SmPGMA78U6H5k6PIF6-xZ95CK6bps8MGXpmHocN951sxAwZrfg4t22KXz7FHttKXLHSXhXoGSHnT-JGGRaAGAYYJ', 7200, '2017-10-04 02:37:17'),(2, 'HfxVguZFIK-k2td4iK_BTpFYrPdAakIJjNgoxmrBSVC9QxptpVIT5f6pyacCZs9uG7KoGr9eKMAKqmOAojEQ9r5cjWJVTB2kZHV4PxZBiRdQNfjO-mvwV7yRYziyvt3fJAAfACAFWW', 7200, '2017-10-19 17:18:44'),(3, 'uz1poQuY2Nnh9ruHahPaVPHeh1wJUPY8YdEK_yBeTi_Dj7pp3Fg-2RH8qMrMNERfML2SgM2g6KeRN8MkwdajI2Iv0pt1pthiOAJh7gYsOAVnLsw85I-RqijPs6OZDmTyTDEcACAYIJ', 7200, '2017-10-20 10:21:38'),(4, 'Lr9n-xw6iePB3C6idqHmNxtwiMIsee5zxDpIHRd1Q88_hAMM44hpGuOhm6jZLMR1Sg-q5x0E6THYr_IKnbf2JkbVd0KLymAWTxDIO3j7ygWWG7WugeW-JTHAyzLdEXTqAFTcADAWBP', 7200, '2017-10-20 12:36:17'),(5, '5y7rSHWmpqM8eyQxBsWFsZsa2hvfuh9G_keZMY6Oq_vtQu-R1IKZYGW1Has5qVY3At3V1kCATQKdpplyErV1J62rizR8ozb2w6uWczMg1vvPUqVueAed9mWmTzTxHXO8EBFeAAAMJN', 7200, '2017-10-20 14:13:51');
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`wx_config` WRITE;
DELETE FROM `jrhot_wx`.`wx_config`;
INSERT INTO `jrhot_wx`.`wx_config` (`config_code`,`config_type`,`config_label`,`config_content`,`config_value`) VALUES ('3D6B2951C9854867A95B90B7203A88A0', 'text', '开发者ID (AppID)', NULL, 'wx00979ffb52ef6c4f'),('95D5D4D019FB4E1AAF07BDF8E2C4ECD3', 'text', '服务器地址 (URL)', NULL, 'http://smejr.gov.cn/wx'),('9B5609D40BB74677AD1F45E599BC1693', 'radio', '消息加解密方式', '<select><option value=\"0\">明文模式</option><option value=\"1\">兼容模式</option><option value=\"2\">安全模式（推荐）</option></select>', '0'),('A757DBFF22A743C199EDEA0B391A5F20', 'text', '消息加解密密钥 (EncodingAESKey)', NULL, '4AeBhntTAFgd3svDoAaxWeyaHJKbDs22kWecWrwgMwM'),('EEC07125435944E8BAB86AD56B1967F3', 'text', '开发者密码 (AppSecret)', NULL, '219810842bebe6c15351d938eb577953'),('F9B217F60F8446A488BA74CB480D1E9E', 'text', 'JS接口安全域名', NULL, 'smejr.gov.cn'),('FAEC1C043DD544DAA65EAC4BE6C9F34A', 'text', '令牌 (Token)', NULL, 'uW4FnzeSKkGtoLgPV8fwRvP041EFURDX');
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`wx_menu` WRITE;
DELETE FROM `jrhot_wx`.`wx_menu`;
INSERT INTO `jrhot_wx`.`wx_menu` (`id`,`parent_id`,`srt`,`node_type`,`node_name`,`node_key`,`node_url`,`node_media_id`,`node_appid`,`node_pagepath`,`rich_content`,`deleted`,`cruser`,`crtime`,`mduser`,`mdtime`) VALUES (1, 0, 1, 'click', '点击', 'click_key', NULL, NULL, NULL, NULL, '即将上线，敬请期待！', 1, 'admin', '2017-09-30 23:44:21', NULL, NULL),(2, 0, 2, 'view', '汉语拼音', NULL, 'http://smejr.gov.cn/wx/pinyin.html', '', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL),(3, 0, 3, 'media_id', '媒体', NULL, NULL, 'brxfNLiYfD_btXNBiVibixJmKSsWYxLpDiyfuALAeUo', NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`wx_ticket` WRITE;
DELETE FROM `jrhot_wx`.`wx_ticket`;
INSERT INTO `jrhot_wx`.`wx_ticket` (`id`,`ticket`,`expires_in`,`expires_time`) VALUES (1, 'HoagFKDcsGMVCIY2vOjf9to9DRFzSjGPLZSBfs4oKXxAvh4ghhnmAO1PFkchDfi803LuV1NDMDhqqSC5-bIyZg', 7200, '2017-10-04 02:37:17'),(2, 'HoagFKDcsGMVCIY2vOjf9to9DRFzSjGPLZSBfs4oKXyOHLPQPBpEDoE9mVh47N8kUYUTtPAEKyY94yvTO4atsg', 7200, '2017-10-19 17:18:44'),(3, 'HoagFKDcsGMVCIY2vOjf9to9DRFzSjGPLZSBfs4oKXw17H1GqLqNgBe3JUxxH0_pd_iLHeTh7fCKwGn1UR8U9Q', 7200, '2017-10-20 10:21:38'),(4, 'HoagFKDcsGMVCIY2vOjf9to9DRFzSjGPLZSBfs4oKXwqx5_RgpftnAYARRyku1KwzF15heM0iqY_Fsp4Z26qXA', 7200, '2017-10-20 12:36:17'),(5, 'HoagFKDcsGMVCIY2vOjf9to9DRFzSjGPLZSBfs4oKXzYIVu1uZ0rBxY-NOD3fb_PIP045UOtQHSzAeMcq4Y1JQ', 7200, '2017-10-20 14:13:51');
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`wx_user_info` WRITE;
DELETE FROM `jrhot_wx`.`wx_user_info`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`wx_web_access_token` WRITE;
DELETE FROM `jrhot_wx`.`wx_web_access_token`;
UNLOCK TABLES;
COMMIT;
