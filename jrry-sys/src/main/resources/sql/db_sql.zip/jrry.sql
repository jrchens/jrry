/*
MySQL Backup
Database: jrry
Backup Time: 2018-05-07 23:30:27
*/

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS `jrry`.`mpms_category`;
DROP TABLE IF EXISTS `jrry`.`sys_config`;
DROP TABLE IF EXISTS `jrry`.`sys_dictionary`;
DROP TABLE IF EXISTS `jrry`.`sys_group`;
DROP TABLE IF EXISTS `jrry`.`sys_permission`;
DROP TABLE IF EXISTS `jrry`.`sys_role`;
DROP TABLE IF EXISTS `jrry`.`sys_role_permission_relation`;
DROP TABLE IF EXISTS `jrry`.`sys_user`;
DROP TABLE IF EXISTS `jrry`.`sys_user_group_relation`;
DROP TABLE IF EXISTS `jrry`.`sys_user_role_relation`;
CREATE TABLE `mpms_category` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `parent_id` bigint(20) unsigned DEFAULT '0' COMMENT '上级编号',
  `code` varchar(36) NOT NULL COMMENT '代码',
  `name` varchar(20) NOT NULL COMMENT '名称',
  `full_name` varchar(50) DEFAULT NULL COMMENT '全称',
  `srt` int(4) unsigned DEFAULT '1' COMMENT '排序',
  `level` int(4) unsigned DEFAULT '1' COMMENT '层次',
  `is_viewable` tinyint(1) DEFAULT '1' COMMENT '是否可见',
  `is_disabled` tinyint(1) unsigned DEFAULT '0' COMMENT '是否启用',
  `is_deleted` tinyint(1) unsigned DEFAULT '0' COMMENT '是否删除',
  `cruser` varchar(50) NOT NULL COMMENT '创建用户',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(50) DEFAULT NULL COMMENT '更新用户',
  `mdtime` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uni_code_and_ver` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
CREATE TABLE `sys_config` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cfg_code` varchar(36) NOT NULL,
  `cfg_type` tinyint(4) unsigned NOT NULL DEFAULT '1',
  `cfg_name` varchar(50) NOT NULL,
  `cfg_value` varchar(200) NOT NULL,
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cruser` varchar(50) NOT NULL,
  `crtime` datetime NOT NULL,
  `mduser` varchar(50) DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cfg_code` (`cfg_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
CREATE TABLE `sys_dictionary` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `code` varchar(50) DEFAULT NULL COMMENT '代码',
  `parent_code` varchar(50) DEFAULT NULL COMMENT '父代码',
  `name` varchar(50) DEFAULT NULL COMMENT '名称',
  `item_value` varchar(50) DEFAULT NULL COMMENT '值',
  `srt` int(4) unsigned DEFAULT '1' COMMENT '排序',
  `is_disabled` tinyint(1) unsigned DEFAULT '0' COMMENT '已禁用',
  `is_deleted` tinyint(1) unsigned DEFAULT '0' COMMENT '是否删除',
  `cruser` varchar(50) NOT NULL COMMENT '创建用户',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(50) DEFAULT NULL COMMENT '更新用户',
  `mdtime` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
CREATE TABLE `sys_group` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `group_name` varchar(50) NOT NULL,
  `viewname` varchar(50) NOT NULL,
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cruser` varchar(50) NOT NULL,
  `crtime` datetime NOT NULL,
  `mduser` varchar(50) DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_name` (`group_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
CREATE TABLE `sys_permission` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(50) NOT NULL,
  `permission` varchar(200) NOT NULL,
  `viewname` varchar(50) NOT NULL,
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cruser` varchar(50) NOT NULL,
  `crtime` datetime NOT NULL,
  `mduser` varchar(50) DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permission` (`permission`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
CREATE TABLE `sys_role` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) NOT NULL,
  `viewname` varchar(50) NOT NULL,
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cruser` varchar(50) NOT NULL,
  `crtime` datetime NOT NULL,
  `mduser` varchar(50) DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_name` (`role_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
CREATE TABLE `sys_role_permission_relation` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) NOT NULL,
  `permission` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
CREATE TABLE `sys_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `viewname` varchar(50) NOT NULL,
  `password` varchar(128) NOT NULL,
  `password_salt` varchar(16) NOT NULL,
  `email` varchar(50) NOT NULL,
  `is_disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_locked` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cruser` varchar(50) NOT NULL,
  `crtime` datetime NOT NULL,
  `mduser` varchar(50) DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`) USING HASH,
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
CREATE TABLE `sys_user_group_relation` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `group_name` varchar(50) NOT NULL,
  `is_def` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
CREATE TABLE `sys_user_role_relation` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `role_name` varchar(50) NOT NULL,
  `is_def` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
BEGIN;
LOCK TABLES `jrry`.`mpms_category` WRITE;
DELETE FROM `jrry`.`mpms_category`;
INSERT INTO `jrry`.`mpms_category` (`id`,`parent_id`,`code`,`name`,`full_name`,`srt`,`level`,`is_viewable`,`is_disabled`,`is_deleted`,`cruser`,`crtime`,`mduser`,`mdtime`) VALUES (1, 0, '65dd93c6-6dac-4292-baaf-3da0137d4613', '类别管理', '类别管理', 1, 1, 1, 0, 0, 'admin', '2018-03-23 16:47:41', NULL, NULL),(2, 1, '69393683-a24b-4d2c-8f34-1f5b980d6109', '重点项目', '重点项目', 2, 2, 1, 0, 0, 'admin', '2018-03-23 13:56:35', 'admin', '2018-03-23 16:04:41'),(3, 2, 'ddb0878a-cad4-4f46-9392-b4987861b870', '镇江市级', '镇江市级', 1, 3, 1, 0, 0, 'admin', '2018-03-23 15:15:29', 'admin', '2018-03-24 08:11:54'),(4, 2, 'e5e975bc-127f-44ad-9df1-27aa1fe8f992', '镇江技改', '镇江技改', 2, 3, 1, 0, 0, 'admin', '2018-03-23 16:02:01', NULL, NULL),(5, 2, '9f1eed69-973c-43a7-be1b-dbc34ce8d36b', '句容市级', '句容市级', 3, 3, 1, 0, 0, 'admin', '2018-03-23 16:08:03', NULL, NULL),(6, 2, 'a6c942dc-3890-4779-9aa4-f72cbd429d2b', '句容技改', '句容技改', 4, 3, 1, 0, 0, 'admin', '2018-03-23 16:08:25', NULL, NULL),(12, 2, 'debbe980-438e-4a2c-9a08-fcaaf1d97785', '新节点2', '新节点2', 6, 3, 1, 0, 0, 'admin', '2018-03-23 21:38:51', 'admin', '2018-03-24 08:27:50'),(13, 2, '59978c0a-98fd-4c9f-9c2b-e38ae57a543b', '新节点1', '新节点1', 5, 3, 1, 0, 0, 'admin', '2018-03-23 22:33:20', 'admin', '2018-03-24 08:12:41'),(14, 2, '52a9f390-3534-4c98-b114-3b237f920818', '新节点3', '新节点3', 7, 3, 1, 0, 0, 'admin', '2018-03-24 08:12:52', 'admin', '2018-03-24 08:12:59'),(15, 2, 'cb823f1f-7073-4ad0-92ee-56d95ad8e140', '新节点4', '新节点4', 8, 3, 1, 0, 0, 'admin', '2018-03-24 08:13:37', 'admin', '2018-03-24 08:31:01');
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrry`.`sys_config` WRITE;
DELETE FROM `jrry`.`sys_config`;
INSERT INTO `jrry`.`sys_config` (`id`,`cfg_code`,`cfg_type`,`cfg_name`,`cfg_value`,`is_deleted`,`cruser`,`crtime`,`mduser`,`mdtime`) VALUES (1, '6e1352df-2c9d-4811-8359-ac0d68e2291e', 2, '默认用户组', 'guest', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(2, '292d8ffc-e394-49ce-8aba-71499f35fa55', 2, '默认角色', 'guest', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(3, 'UPLOAD_BASE_PATH', 1, '上传路径', '/usr/local/var/upload', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(4, 'ASSETS_DOMAIN_NAME', 1, '静态资源域名', 'http://assets.local.com', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrry`.`sys_dictionary` WRITE;
DELETE FROM `jrry`.`sys_dictionary`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrry`.`sys_group` WRITE;
DELETE FROM `jrry`.`sys_group`;
INSERT INTO `jrry`.`sys_group` (`id`,`group_name`,`viewname`,`is_deleted`,`cruser`,`crtime`,`mduser`,`mdtime`) VALUES (1, 'admin', '管理员', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(2, 'user', '注册用户', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(3, 'guest', '游客', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrry`.`sys_permission` WRITE;
DELETE FROM `jrry`.`sys_permission`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrry`.`sys_role` WRITE;
DELETE FROM `jrry`.`sys_role`;
INSERT INTO `jrry`.`sys_role` (`id`,`role_name`,`viewname`,`is_deleted`,`cruser`,`crtime`,`mduser`,`mdtime`) VALUES (1, 'admin', '管理员', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(2, 'user', '注册用户', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(3, 'guest', '游客', 0, 'admin', '2010-10-10 10:10:10', NULL, NULL);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrry`.`sys_role_permission_relation` WRITE;
DELETE FROM `jrry`.`sys_role_permission_relation`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrry`.`sys_user` WRITE;
DELETE FROM `jrry`.`sys_user`;
INSERT INTO `jrry`.`sys_user` (`id`,`username`,`viewname`,`password`,`password_salt`,`email`,`is_disabled`,`is_locked`,`is_deleted`,`cruser`,`crtime`,`mduser`,`mdtime`) VALUES (1, 'admin', 'Admin', 'd39c172995e5e51bb9f2d30fee1c3fa09c7f26f15f8b991f629d7306a333ca388b5dbe807d571bc43442d549d71ae1335c3741cd8ae255be50b4c6e1a6d9fd93', 'ZuVQXbee', 'jrchens@126.com', 0, 0, 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(2, 'jason', 'Jason', 'efafe4276436b21d03b62a75495a9e632317baa0494ab423c6ba6a2119acef0026d04dd178eea3c3b967db04be71d7bc4631900cb6172dcfb835acd355ef789a', 'w0N3N6OL', 'jrchens@163.com', 0, 0, 0, 'admin', '2010-10-10 10:10:10', NULL, NULL),(3, 'mason', 'Mason', '35403eb3d9a683a86d09a5d6b964e22d0efe0907ed386c10ebee89c1a44e2ee00ff27c258607f2fb7c4a922daf1b29bfa3373986d8bbab6fb1f6527170a95e9f', 'sPxiGWxX', 'jrchens@foxmail.com', 0, 0, 0, 'admin', '2010-10-10 10:10:10', NULL, NULL);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrry`.`sys_user_group_relation` WRITE;
DELETE FROM `jrry`.`sys_user_group_relation`;
INSERT INTO `jrry`.`sys_user_group_relation` (`id`,`username`,`group_name`,`is_def`) VALUES (1, 'admin', 'admin', 1),(2, 'jason', 'user', 1),(3, 'mason', 'guest', 1);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrry`.`sys_user_role_relation` WRITE;
DELETE FROM `jrry`.`sys_user_role_relation`;
INSERT INTO `jrry`.`sys_user_role_relation` (`id`,`username`,`role_name`,`is_def`) VALUES (1, 'admin', 'admin', 1),(2, 'jason', 'user', 1),(3, 'mason', 'guest', 1);
UNLOCK TABLES;
COMMIT;
