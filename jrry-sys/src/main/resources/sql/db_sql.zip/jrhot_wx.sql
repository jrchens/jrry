/*
MySQL Backup
Database: jrhot_wx
Backup Time: 2018-03-10 22:12:44
*/

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS `jrhot_wx`.`cms_article`;
DROP TABLE IF EXISTS `jrhot_wx`.`engineering`;
DROP TABLE IF EXISTS `jrhot_wx`.`engineering_progress`;
DROP TABLE IF EXISTS `jrhot_wx`.`engineering_progress_picture`;
DROP TABLE IF EXISTS `jrhot_wx`.`project`;
DROP TABLE IF EXISTS `jrhot_wx`.`section`;
DROP TABLE IF EXISTS `jrhot_wx`.`sys_api_notification`;
DROP TABLE IF EXISTS `jrhot_wx`.`wx_access_token`;
DROP TABLE IF EXISTS `jrhot_wx`.`wx_config`;
DROP TABLE IF EXISTS `jrhot_wx`.`wx_jsapi_ticket`;
DROP TABLE IF EXISTS `jrhot_wx`.`wx_menu`;
DROP TABLE IF EXISTS `jrhot_wx`.`wx_menu_match_rule`;
DROP TABLE IF EXISTS `jrhot_wx`.`wx_pay_unifiedorder`;
DROP TABLE IF EXISTS `jrhot_wx`.`wx_tag`;
DROP TABLE IF EXISTS `jrhot_wx`.`wx_user_info`;
DROP TABLE IF EXISTS `jrhot_wx`.`wx_user_info_engineering_relation`;
DROP TABLE IF EXISTS `jrhot_wx`.`wx_user_info_tag_relation`;
DROP TABLE IF EXISTS `jrhot_wx`.`wx_user_red_pack`;
DROP TABLE IF EXISTS `jrhot_wx`.`wx_user_sms`;
DROP TABLE IF EXISTS `jrhot_wx`.`wx_web_access_token`;
CREATE TABLE `cms_article` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `article_category` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '类别',
  `article_picture` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '封面图片',
  `article_title` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '标题',
  `article_summary` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '摘要',
  `article_content` text COLLATE utf8_unicode_ci NOT NULL COMMENT '内容',
  `article_author` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '作者',
  `sort` int(11) DEFAULT NULL COMMENT '排序',
  `publish_date` date NOT NULL COMMENT '发布日期',
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `cruser` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '创建用户',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '更新用户',
  `mdtime` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `engineering` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `project_number` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '项目编号',
  `section_number` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '标段编号',
  `engineering_number` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '工程编号',
  `engineering_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '工程名称',
  `engineering_location` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '建设地点',
  `specification_model` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '规格型号',
  `quantity` decimal(15,2) NOT NULL COMMENT '数量',
  `unit` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT '单位',
  `unit_price` decimal(15,2) NOT NULL COMMENT '单价',
  `total_price` decimal(15,2) NOT NULL COMMENT '总价',
  `completed` decimal(15,2) DEFAULT NULL COMMENT '实完数量',
  `progress` decimal(15,2) DEFAULT NULL COMMENT '进度',
  `remark` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '备注',
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `cruser` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '创建用户',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '更新用户',
  `mdtime` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `engineering_progress` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `project_number` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '项目编号',
  `section_number` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '标段编号',
  `engineering_number` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '工程编号',
  `engineering_picture` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '上传图片',
  `completed` decimal(15,2) NOT NULL COMMENT '实完数量',
  `progress` decimal(15,2) NOT NULL COMMENT '工程进度（百分比）',
  `remark` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '备注',
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `cruser` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '创建用户',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '更新用户',
  `mdtime` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `engineering_progress_picture` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `engineering_progress_number` bigint(20) NOT NULL,
  `engineering_progress_picture` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `media_id` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '微信多媒体编号',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `project` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `project_number` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '项目编号',
  `project_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '项目名称',
  `project_location` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '建设地点',
  `project_year` varchar(4) COLLATE utf8_unicode_ci NOT NULL COMMENT '年度',
  `project_category` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '类别',
  `completed` decimal(15,2) DEFAULT NULL COMMENT '实完数量',
  `progress` decimal(15,2) DEFAULT NULL COMMENT '进度',
  `remark` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '备注',
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `cruser` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '创建用户',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '更新用户',
  `mdtime` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `section` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `project_number` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '项目编号',
  `section_number` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '标段编号',
  `section_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT '标段名称',
  `section_location` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '建设地点',
  `tender` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '中标人',
  `tender_price` decimal(15,2) NOT NULL COMMENT '中标价',
  `section_manager` varchar(32) COLLATE utf8_unicode_ci NOT NULL COMMENT '项目经理',
  `manager_phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL COMMENT '联系电话',
  `completed` decimal(15,2) DEFAULT NULL COMMENT '实完数量',
  `progress` decimal(15,2) DEFAULT NULL COMMENT '进度',
  `remark` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '备注',
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `cruser` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '创建用户',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '更新用户',
  `mdtime` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `sys_api_notification` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `code` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `wx_access_token` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `access_token` varchar(200) DEFAULT NULL,
  `expires_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
CREATE TABLE `wx_config` (
  `cfg_code` varchar(36) COLLATE utf8_unicode_ci NOT NULL,
  `cfg_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `cfg_value` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`cfg_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
CREATE TABLE `wx_jsapi_ticket` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ticket` varchar(200) DEFAULT NULL,
  `expires_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
CREATE TABLE `wx_menu` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `node_type` varchar(50) DEFAULT NULL,
  `node_name` varchar(50) DEFAULT NULL,
  `node_key` varchar(50) DEFAULT NULL,
  `node_url` varchar(500) DEFAULT NULL,
  `node_media_id` varchar(50) DEFAULT NULL,
  `node_appid` varchar(50) DEFAULT NULL,
  `node_pagepath` varchar(200) DEFAULT NULL,
  `node_scope` varchar(50) DEFAULT NULL,
  `node_state` varchar(50) DEFAULT NULL,
  `is_custom` tinyint(1) unsigned DEFAULT '0' COMMENT '是否个性化菜单',
  `menuid` bigint(20) DEFAULT NULL COMMENT '微信个性化菜单编号',
  `sort` int(11) unsigned DEFAULT '1',
  `is_disabled` tinyint(1) unsigned DEFAULT '0',
  `cruser` varchar(50) NOT NULL,
  `crtime` datetime NOT NULL,
  `mduser` varchar(50) DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8;
CREATE TABLE `wx_menu_match_rule` (
  `id` bigint(20) unsigned NOT NULL COMMENT '菜单外键',
  `tag_id` bigint(20) DEFAULT NULL COMMENT '用户标签',
  `sex` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '性别',
  `country` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '国家信息',
  `province` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '省份信息',
  `city` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '城市信息',
  `client_platform_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '客户端版本',
  `language` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '语言信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;
CREATE TABLE `wx_pay_unifiedorder` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `out_trade_no` varchar(50) NOT NULL,
  `appid` varchar(32) DEFAULT NULL,
  `mch_id` varchar(32) DEFAULT NULL,
  `device_info` varchar(32) DEFAULT NULL,
  `nonce_str` varchar(32) DEFAULT NULL,
  `sign` varchar(32) DEFAULT NULL,
  `sign_type` varchar(32) DEFAULT NULL,
  `body` varchar(128) DEFAULT NULL,
  `detail` text,
  `attach` varchar(127) DEFAULT NULL,
  `fee_type` varchar(16) DEFAULT NULL,
  `total_fee` int(11) DEFAULT NULL,
  `spbill_create_ip` varchar(16) DEFAULT NULL,
  `time_start` varchar(14) DEFAULT NULL,
  `time_expire` varchar(14) DEFAULT NULL,
  `goods_tag` varchar(32) DEFAULT NULL,
  `notify_url` varchar(256) DEFAULT NULL,
  `trade_type` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`out_trade_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE `wx_tag` (
  `id` bigint(20) unsigned NOT NULL COMMENT '主键',
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '标签名',
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `cruser` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '创建用户',
  `crtime` datetime NOT NULL COMMENT '创建时间',
  `mduser` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '更新用户',
  `mdtime` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `wx_user_info` (
  `openid` varchar(50) NOT NULL DEFAULT '',
  `subscribe` int(1) unsigned DEFAULT NULL,
  `viewname` varchar(50) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `nickname` varchar(50) DEFAULT NULL,
  `sex` int(1) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `headimgurl` varchar(500) DEFAULT NULL,
  `unionid` varchar(50) DEFAULT NULL,
  `remark` varchar(200) DEFAULT NULL,
  `subscribe_time` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`openid`) USING BTREE,
  UNIQUE KEY `openid` (`openid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
CREATE TABLE `wx_user_info_engineering_relation` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `openid` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '微信用户编号',
  `engineering_number` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '工程编号',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `wx_user_info_tag_relation` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `openid` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `tag_id` int(4) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE `wx_user_red_pack` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `openid` varchar(50) DEFAULT NULL,
  `appid` varchar(50) DEFAULT NULL,
  `mch_id` varchar(50) DEFAULT NULL,
  `product_body` varchar(200) DEFAULT NULL,
  `out_trade_no` varchar(50) DEFAULT NULL,
  `total_fee` int(10) unsigned DEFAULT NULL,
  `spbill_create_ip` varchar(50) DEFAULT NULL,
  `trade_type` varchar(50) DEFAULT NULL,
  `device_info` varchar(50) DEFAULT NULL,
  `prepay_id` varchar(50) DEFAULT NULL,
  `time_start` datetime DEFAULT NULL,
  `bank_type` varchar(50) DEFAULT NULL,
  `time_end` datetime DEFAULT NULL,
  `transaction_id` varchar(50) DEFAULT NULL,
  `pre_total_amount` int(11) DEFAULT '0',
  `total_amount` int(11) DEFAULT '0',
  `send_listid` varchar(50) DEFAULT NULL,
  `partner_trade_no` varchar(50) DEFAULT NULL COMMENT '企业付款-商户订单号',
  `payment_no` varchar(50) DEFAULT NULL COMMENT '企业付款-微信订单号',
  `return_code` varchar(50) DEFAULT NULL,
  `payment_time` datetime DEFAULT NULL COMMENT '企业付款-微信支付成功时间',
  `result_code` varchar(50) DEFAULT NULL COMMENT '业务结果',
  `return_msg` varchar(200) DEFAULT NULL COMMENT '返回信息',
  `err_code_des` varchar(200) DEFAULT NULL COMMENT '错误代码描述',
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cruser` varchar(50) DEFAULT NULL,
  `crtime` datetime DEFAULT NULL,
  `mduser` varchar(50) DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`,`is_deleted`) USING BTREE,
  UNIQUE KEY `openid` (`openid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `wx_user_sms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `openid` varchar(50) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `sms_content` varchar(200) DEFAULT NULL,
  `expires_time` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) unsigned NOT NULL,
  `cruser` varchar(50) NOT NULL,
  `crtime` datetime NOT NULL,
  `mduser` varchar(50) DEFAULT NULL,
  `mdtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `wx_web_access_token` (
  `openid` varchar(100) NOT NULL DEFAULT '',
  `access_token` varchar(200) DEFAULT NULL,
  `expires_time` datetime DEFAULT NULL,
  `refresh_token` varchar(200) DEFAULT NULL,
  `scope` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`openid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
BEGIN;
LOCK TABLES `jrhot_wx`.`cms_article` WRITE;
DELETE FROM `jrhot_wx`.`cms_article`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`engineering` WRITE;
DELETE FROM `jrhot_wx`.`engineering`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`engineering_progress` WRITE;
DELETE FROM `jrhot_wx`.`engineering_progress`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`engineering_progress_picture` WRITE;
DELETE FROM `jrhot_wx`.`engineering_progress_picture`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`project` WRITE;
DELETE FROM `jrhot_wx`.`project`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`section` WRITE;
DELETE FROM `jrhot_wx`.`section`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`sys_api_notification` WRITE;
DELETE FROM `jrhot_wx`.`sys_api_notification`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`wx_access_token` WRITE;
DELETE FROM `jrhot_wx`.`wx_access_token`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`wx_config` WRITE;
DELETE FROM `jrhot_wx`.`wx_config`;
INSERT INTO `jrhot_wx`.`wx_config` (`cfg_code`,`cfg_name`,`cfg_value`) VALUES ('0655f806-95fd-42ef-a870-03ceb6f4f3f6', '微信商户支付签名方式', 'MD5'),('1ad13e39-fed3-4635-994d-1d4c2d7f0ae4', '银行卡类型', 'CFT'),('2f01712c-4a1c-4d0f-a442-ee14337e6f21', '红包-商户名称', '煜亭实业'),('31fcae72-9b73-4f71-8934-3755be459e96', '红包-活动名称', '现金红包'),('34c10bf0-fe3b-4ff0-846d-66acf338e7fb', '上传路径', '/www/wwwlogs'),('3d628bf5-f2d4-4147-910c-a6537cfe607f', '分享备注', '分享备注'),('429f8828-7512-4c01-bd71-10cd8acff4c3', '微信商户设备编号', '16'),('4ee0aa32-6944-4bfd-a497-293a755da064', '支付商品价格', '100'),('5d34a997-4f18-4a0a-b9f4-1378526091d4', '红包-备注', '煜亭实业-现金红包'),('5e8e7c9f-b57d-45a3-9b50-828b0f0277d9', '消息加解密密钥(EncodingAESKey)', 'nO3YB4jD9Vs1Wsys3tt9r92t71t2B64cB4194KsTwwW'),('7328894b-699d-46a0-a2ef-b1d4a2ebe109', '分享链接', 'http://smejr.gov.cn/jrhot-wx/pay'),('760e9207-bae5-416f-9f89-52e7eab01113', '分享标题', '分享标题'),('76900565-ac11-4a9f-a990-1475db91db2f', '开发者ID(AppID)', 'wx0fd9ea5b91f95791'),('7f2dbe5c-d201-4225-a1d0-777f43c8f3bc', '令牌(Token)', 'PMmF2wQIs75E4QSFWsV4ve4qVWMV3555'),('8128125a-d95b-40cb-840e-477abfc594a7', '开发者密码(AppSecret)', '0746cddc2d186cacf7783de1a22902ac'),('8429818f-d56f-409f-870a-45be27bd2e32', '知信注册通知模板', '您的手机号：%s，注册验证码：%s，一天内提交有效！【句容热线网】'),('906e0d6d-cf73-43ec-a797-43750bf802e3', '短信平台密码', '子'),('a290f6b4-935e-4826-8ab1-55232e9d779d', '监理用户标签编号', '100'),('ac7db286-f07a-45e0-86a2-971db4e76006', '红包最大金额', '110'),('b7b61a4e-5cf3-4943-aabf-8ca16d68707b', '红包支付方式', 'PROMOTION_TRANSFERS'),('ba69af02-08af-4cab-9c89-1ead6f30c363', '分享图片链接', 'http://smejr.gov.cn/jrhot-wx/resources/images/d2836bc79061a86e2aacfa42939faabe.jpg'),('bf298c60-a04f-4b9b-a125-e2768cf43b43', '微信商户平台设置的密钥key', 'auqlrlGlvnbZd6Qi4RqPU7VHfNrxxKoU'),('c9093378-acb4-49c2-8c7e-c6a4be306e36', '支付商品名称', '煜亭实业-抢红包'),('cba9941a-e8ad-4138-ae46-add9006aafec', '企业付款-企业付款描述信息', '煜亭实业-企业现金红包'),('ccff1cec-a470-45bb-b6e3-313a62944978', '服务器地址(URL)', 'http://smejr.gov.cn/jracd-wx/'),('d3cbc840-c8ca-4d39-ab60-e62535728338', '上传域名', 'http://dl.com'),('d62242a3-307a-4d3e-8c66-9a5810517851', '微信支付结果通知回调地址', 'http://smejr.gov.cn/jrhot-wx/pay/callback'),('dded3dab-1140-4717-a2af-0c319b74aa0b', '红包金额', '100,101,102,103,104,105'),('e08c0c07-00f0-4f18-8729-2e52f7bdff86', '微信商户编号', '1488351332'),('eae604f8-bee4-484d-b44c-2affd4aeb47c', '消息加解密方式(0/明文模式,1/兼容模式,2/安全模式)', '0'),('ec63b16c-3966-4039-801b-e51223f81cb4', '红包总金额（分）', '1000'),('f126a3d9-5c0b-4354-bb5e-8101a053b611', '短信平台用户名', '金'),('f710433b-c3dd-461e-a1b4-d1e57d58f23d', '红包-红包祝福语', '恭喜发财');
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`wx_jsapi_ticket` WRITE;
DELETE FROM `jrhot_wx`.`wx_jsapi_ticket`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`wx_menu` WRITE;
DELETE FROM `jrhot_wx`.`wx_menu`;
INSERT INTO `jrhot_wx`.`wx_menu` (`id`,`parent_id`,`node_type`,`node_name`,`node_key`,`node_url`,`node_media_id`,`node_appid`,`node_pagepath`,`node_scope`,`node_state`,`is_custom`,`menuid`,`sort`,`is_disabled`,`cruser`,`crtime`,`mduser`,`mdtime`) VALUES (1, 0, 'root', '微信菜单管理', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 1, 0, 'admin', '2018-01-31 21:31:18', NULL, NULL),(2, 1, 'default', '默认菜单', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 1, 0, 'admin', '2018-01-31 21:31:54', NULL, NULL),(86, 2, 'view', '支付', NULL, 'http://smejr.gov.cn/jrhot-wx/pay', NULL, NULL, NULL, 'snsapi_base', NULL, 0, NULL, 1, 0, 'admin', '2018-01-31 21:32:27', NULL, NULL);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`wx_menu_match_rule` WRITE;
DELETE FROM `jrhot_wx`.`wx_menu_match_rule`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`wx_pay_unifiedorder` WRITE;
DELETE FROM `jrhot_wx`.`wx_pay_unifiedorder`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`wx_tag` WRITE;
DELETE FROM `jrhot_wx`.`wx_tag`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`wx_user_info` WRITE;
DELETE FROM `jrhot_wx`.`wx_user_info`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`wx_user_info_engineering_relation` WRITE;
DELETE FROM `jrhot_wx`.`wx_user_info_engineering_relation`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`wx_user_info_tag_relation` WRITE;
DELETE FROM `jrhot_wx`.`wx_user_info_tag_relation`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`wx_user_red_pack` WRITE;
DELETE FROM `jrhot_wx`.`wx_user_red_pack`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`wx_user_sms` WRITE;
DELETE FROM `jrhot_wx`.`wx_user_sms`;
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `jrhot_wx`.`wx_web_access_token` WRITE;
DELETE FROM `jrhot_wx`.`wx_web_access_token`;
UNLOCK TABLES;
COMMIT;
